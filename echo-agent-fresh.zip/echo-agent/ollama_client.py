"""
ollama_client.py -- duenner Wrapper um die lokale Ollama-HTTP-API.

Erwartet einen laufenden `ollama serve` auf dieser Maschine (Standard-Port
11434). Modell ueber Env-Var ECHO_MODEL waehlbar, Default "llama3.1".
"""

import os
import requests

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434")
MODEL = os.environ.get("ECHO_MODEL", "llama3.1")


def chat(messages, temperature=0.2):
    """messages: Liste von {"role": "system"|"user"|"assistant", "content": str}"""
    resp = requests.post(
        f"{OLLAMA_URL}/api/chat",
        json={
            "model": MODEL,
            "messages": messages,
            "stream": False,
            "options": {"temperature": temperature},
        },
        timeout=120,
    )
    resp.raise_for_status()
    data = resp.json()
    return data["message"]["content"]
