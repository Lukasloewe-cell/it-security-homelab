"""
init_db.py -- legt die SQLite-Datenbank fuer den ECHO Support Agent neu an.

Wie bei NEXORA: alle Queries parametrisiert, SQLi ist nicht die Luecke
hier. Die Luecken diesmal liegen auf der Agenten-Ebene (Prompt Injection,
Excessive Agency, fehlende Tool-Autorisierung).
"""

import hashlib
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "echo.db"


def hash_pw(s: str) -> str:
    return hashlib.md5(s.encode()).hexdigest()


USERS = [
    # (username, password_klartext, role)
    ("admin", "Ech0_Supp0rt_R00t!", "admin"),
    ("m.schneider", "sommer2025", "staff"),
    ("kunde1", "passwort456", "customer"),
    ("kunde2", "quantensprung", "customer"),
]

KB_ARTICLES = [
    ("Passwort zuruecksetzen", "Gehe zu Account-Einstellungen und klicke auf 'Passwort aendern'."),
    ("Rechnungen einsehen", "Rechnungen findest du unter Account > Abrechnung."),
    ("Account kuendigen", "Kontaktiere den Support ueber ein Ticket mit Betreff 'Kuendigung'."),
]


def main():
    if DB_PATH.exists():
        DB_PATH.unlink()

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'customer'
        )
    """)
    cur.execute("""
        CREATE TABLE tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            author TEXT NOT NULL,
            subject TEXT NOT NULL,
            body TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'open'
        )
    """)
    cur.execute("""
        CREATE TABLE kb_articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL
        )
    """)

    for username, password, role in USERS:
        cur.execute(
            "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
            (username, hash_pw(password), role),
        )

    # ein paar harmlose Beispiel-Tickets zum Rumspielen
    cur.execute(
        "INSERT INTO tickets (author, subject, body, status) VALUES (?, ?, ?, ?)",
        ("kunde1", "Login funktioniert nicht", "Ich komme seit heute morgen nicht mehr ins Portal.", "open"),
    )
    cur.execute(
        "INSERT INTO tickets (author, subject, body, status) VALUES (?, ?, ?, ?)",
        ("kunde2", "Rechnung fehlt", "Die Rechnung fuer September fehlt in meinem Account.", "open"),
    )

    for title, content in KB_ARTICLES:
        cur.execute("INSERT INTO kb_articles (title, content) VALUES (?, ?)", (title, content))

    conn.commit()
    conn.close()
    print(f"DB angelegt: {DB_PATH}")


if __name__ == "__main__":
    main()
