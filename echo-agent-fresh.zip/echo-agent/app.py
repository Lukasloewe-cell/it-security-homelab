"""
app.py -- ECHO Support Agent, Hauptservice.

Fiktives Produkt (Teil des gleichen NEXORA-Dynamics-Universums wie das
nexora-Lab), absichtlich verwundbar als Uebungsziel fuers eigene Homelab.

Bewusst eingebaute Luecken (Details + Exploit-Walkthrough in README.md):
  1. Agent-Debug-Modus leakt System-Prompt + Tool-Liste (Recon-Baustein)
  2. Direkte Prompt Injection im Agent-Chat
  3. Indirekte Prompt Injection ueber Ticket-Inhalte
  4. Excessive Agency / fehlende Tool-Autorisierung (promote_user, send_report)

Bewusst NICHT enthalten: SQL Injection, Command Injection,
Cookie-/Session-Signing-Angriffe. Alle DB-Queries sind parametrisiert.
"""

import hashlib
import os
from functools import wraps

import sqlite3
from pathlib import Path

from flask import Flask, g, redirect, render_template, request, session, url_for

from agent import run_agent

BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "echo.db"

app = Flask(__name__)
app.secret_key = os.urandom(24)


def hash_pw(s: str) -> str:
    return hashlib.md5(s.encode()).hexdigest()


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def current_user():
    if "user_id" not in session:
        return None
    return get_db().execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped


def staff_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if user is None:
            return redirect(url_for("login"))
        if user["role"] not in ("staff", "admin"):
            return render_template("agent.html", authorized=False), 403
        return view(*args, **kwargs)

    return wrapped


# ---------------------------------------------------------------- Oeffentlich

@app.route("/")
def landing():
    return render_template("landing.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        existing = db.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
        if not username or not password:
            error = "Benutzername und Passwort erforderlich."
        elif existing:
            error = "Benutzername bereits vergeben."
        else:
            db.execute(
                "INSERT INTO users (username, password, role) VALUES (?, ?, 'customer')",
                (username, hash_pw(password)),
            )
            db.commit()
            return redirect(url_for("login"))
    return render_template("register.html", error=error)


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if user and user["password"] == hash_pw(password):
            session["user_id"] = user["id"]
            return redirect(url_for("tickets"))
        error = "Login fehlgeschlagen."
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("landing"))


# ---------------------------------------------------------------- Eingeloggt

@app.route("/tickets", methods=["GET", "POST"])
@login_required
def tickets():
    db = get_db()
    user = current_user()
    error = None
    if request.method == "POST":
        subject = request.form.get("subject", "").strip()
        body = request.form.get("body", "").strip()
        if subject and body:
            db.execute(
                "INSERT INTO tickets (author, subject, body, status) VALUES (?, ?, ?, 'open')",
                (user["username"], subject, body),
            )
            db.commit()
        else:
            error = "Betreff und Nachricht erforderlich."
    rows = db.execute("SELECT * FROM tickets ORDER BY id DESC").fetchall()
    return render_template("tickets.html", tickets=rows, user=user, active="tickets", error=error)


@app.route("/ticket/<int:ticket_id>")
@login_required
def ticket_detail(ticket_id):
    db = get_db()
    row = db.execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,)).fetchone()
    return render_template("ticket_detail.html", ticket=row, user=current_user(), active="tickets")


@app.route("/agent", methods=["GET", "POST"])
@staff_required
def agent_view():
    user = current_user()
    reply = None
    trace = None
    debug_mode = request.form.get("debug") == "on" or request.args.get("debug") == "on"

    if request.method == "POST":
        message = request.form.get("message", "").strip()
        if message:
            reply, trace = run_agent(message)

    return render_template(
        "agent.html",
        authorized=True,
        user=user,
        active="agent",
        reply=reply,
        trace=trace if debug_mode else None,
        debug_mode=debug_mode,
    )


@app.route("/admin")
@login_required
def admin():
    user = current_user()
    if user["role"] != "admin":
        return render_template("admin.html", authorized=False, users=None), 403
    db = get_db()
    users = db.execute("SELECT id, username, role FROM users ORDER BY id").fetchall()
    return render_template("admin.html", authorized=True, users=users, user=user, active="admin")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8083, debug=False)
