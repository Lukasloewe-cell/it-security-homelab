"""
tools.py -- die Werkzeuge, die der ECHO-Agent aufrufen kann.

Konzept (parallel zu NEXORA): der Agent laeuft serverseitig mit seinen
EIGENEN, vollen Rechten -- unabhaengig davon, welcher Mensch gerade mit
ihm chattet oder wessen Ticket er gerade zusammenfasst. Es gibt keine
Pruefung "darf der aktuell eingeloggte User das ueberhaupt ausloesen?".
Der Agent ist damit ein "confused deputy" -- exakt wie der Hauptservice
bei NEXORA, der sich selbst gegenueber dem internen 9090-Service nicht
rechtfertigen musste.

Jedes Tool hat ein "sensitive"-Flag nur zur Dokumentation/README --
es wird an keiner Stelle im Code tatsaechlich geprueft. Das ist
absichtlich so (--- Luecke: Excessive Agency / fehlende Tool-Autorisierung ---).
"""

import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "echo.db"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def list_tickets(**kwargs):
    """Harmlos: listet offene Tickets (id, subject, author)."""
    db = get_db()
    rows = db.execute("SELECT id, author, subject, status FROM tickets").fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_ticket(id, **kwargs):
    """Harmlos: liest ein einzelnes Ticket inkl. Volltext -- genau hier
    kommt der ungefilterte, potenziell von einem Angreifer verfasste
    Text ins Modell-Kontextfenster (indirekte Prompt Injection)."""
    db = get_db()
    row = db.execute("SELECT id, author, subject, body, status FROM tickets WHERE id = ?", (int(id),)).fetchone()
    db.close()
    if not row:
        return {"error": "ticket not found"}
    return dict(row)


def search_kb(query, **kwargs):
    """Harmlos: simple Substring-Suche in der Wissensdatenbank."""
    db = get_db()
    rows = db.execute(
        "SELECT title, content FROM kb_articles WHERE title LIKE ? OR content LIKE ?",
        (f"%{query}%", f"%{query}%"),
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def send_report(url, data="", **kwargs):
    """--- Luecke: SSRF-aehnlicher Exfiltrations-Pfad ---
    Soll eigentlich 'Ticket-Reports an das Monitoring-Webhook des Teams
    schicken'. Der Agent entscheidet selbst, WELCHE url und WELCHE data
    er hier reinpackt -- keine Allowlist, kein Review durch einen
    Menschen bevor der Request raus geht. Wenn eine Ticket-Injection den
    Agenten dazu bringt, hier Ticket-/User-Daten an eine
    angreiferkontrollierte URL zu schicken, sieht das niemand, bis es
    zu spaet ist."""
    import requests

    try:
        resp = requests.post(url, json={"data": data}, timeout=4)
        return {"status": "sent", "response_code": resp.status_code}
    except Exception as exc:
        return {"status": "error", "detail": str(exc)}


def promote_user(username, **kwargs):
    """--- Luecke: Privilege Escalation ueber den Agenten ---
    Identisch zum /internal/admin/promote-Endpunkt bei NEXORA, nur dass
    hier gar kein Key noetig ist -- der Agent selbst IST schon
    autorisiert genug, weil niemand geprueft hat, ob die aktuelle
    Konversation das rechtfertigt."""
    db = get_db()
    user = db.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
    if not user:
        db.close()
        return {"error": "user not found"}
    db.execute("UPDATE users SET role = 'admin' WHERE id = ?", (user["id"],))
    db.commit()
    db.close()
    return {"status": "promoted", "username": username, "role": "admin"}


# Registry: Name -> (Funktion, Beschreibung fuers System-Prompt, sensitive?)
TOOLS = {
    "list_tickets": (list_tickets, "Listet alle Support-Tickets (id, author, subject, status). Keine Argumente.", False),
    "get_ticket": (get_ticket, "Liest ein einzelnes Ticket im Volltext. Args: {\"id\": <int>}", False),
    "search_kb": (search_kb, "Durchsucht die Wissensdatenbank. Args: {\"query\": <string>}", False),
    "send_report": (send_report, "Schickt einen Report-Payload an eine Monitoring-Webhook-URL. Args: {\"url\": <string>, \"data\": <string>}", True),
    "promote_user": (promote_user, "Setzt die Rolle eines Users auf 'admin'. Args: {\"username\": <string>}", True),
}
