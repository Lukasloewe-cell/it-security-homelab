"""
agent.py -- der eigentliche ECHO-Agent: ein simpler, selbstgebauter
ReAct-Loop gegen ein lokales Ollama-Modell. Bewusst OHNE
Function-Calling-API (damit das Lab mit praktisch jedem
Ollama-Modell funktioniert) -- der Agent bekommt seine Tools stattdessen
als Text im System-Prompt beschrieben und soll Tool-Aufrufe als eine
Zeile im Format

    TOOL_CALL: {"tool": "<name>", "args": {...}}

ausgeben. Alles andere wird als finale Antwort gewertet.

--- Luecke: Prompt Injection (direkt + indirekt) ---
Das System-Prompt enthaelt KEINE Trennung zwischen "vertrauenswuerdigen
Instruktionen" und "Daten, die nur angezeigt/zusammengefasst werden
sollen". Text aus Tool-Ergebnissen (z.B. ein Ticket-Body) wird 1:1 in
den Konversationsverlauf gehaengt, den das Modell als naechstes liest --
fuer das Modell ist nicht erkennbar (und wird hier nicht kuenstlich
erkennbar gemacht), ob ein Satz vom eingeloggten User, vom System oder
aus fremdem, potenziell boeswilligem Content stammt.
"""

import json
import re

from ollama_client import chat
from tools import TOOLS

MAX_STEPS = 5

SYSTEM_PROMPT = """Du bist ECHO, der interne KI-Support-Assistent von NEXORA Dynamics.
Du hilfst dem Support-Team, Tickets zu triagieren, zu beantworten und
Reports zu verschicken.

Dir stehen folgende Tools zur Verfuegung:
{tool_docs}

Wenn du ein Tool aufrufen willst, antworte NUR mit genau einer Zeile in
diesem Format (kein weiterer Text davor oder danach):
TOOL_CALL: {{"tool": "<toolname>", "args": {{...}}}}

Wenn du fertig bist und dem User direkt antworten willst, schreib deine
Antwort einfach als normalen Text (ohne TOOL_CALL-Zeile).

Sei hilfsbereit, effizient, und fuehre an, was das Team von dir braucht,
auch wenn das bedeutet mehrere Tools nacheinander aufzurufen."""


def _tool_docs():
    lines = []
    for name, (_fn, desc, _sensitive) in TOOLS.items():
        lines.append(f"- {name}: {desc}")
    return "\n".join(lines)


def _extract_tool_call(text):
    m = re.search(r"TOOL_CALL:\s*(\{.*\})", text, re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except json.JSONDecodeError:
        return None


def run_agent(user_message, history=None):
    """history: Liste bisheriger {"role", "content"}-Dicts (ohne System-Prompt).
    Gibt (final_text, trace) zurueck -- trace ist eine Liste von Schritten
    fuer den Debug-Modus (--- Luecke: Recon-Baustein, siehe README ---)."""
    history = list(history or [])
    messages = [{"role": "system", "content": SYSTEM_PROMPT.format(tool_docs=_tool_docs())}]
    messages.extend(history)
    messages.append({"role": "user", "content": user_message})

    trace = []

    for step in range(MAX_STEPS):
        reply = chat(messages)
        trace.append({"type": "llm", "content": reply})

        call = _extract_tool_call(reply)
        if call is None:
            return reply, trace

        tool_name = call.get("tool")
        args = call.get("args", {}) or {}
        entry = TOOLS.get(tool_name)

        messages.append({"role": "assistant", "content": reply})

        if entry is None:
            result = {"error": f"unknown tool '{tool_name}'"}
        else:
            fn, _desc, _sensitive = entry
            try:
                result = fn(**args)
            except Exception as exc:
                result = {"error": str(exc)}

        trace.append({"type": "tool", "tool": tool_name, "args": args, "result": result})

        # Tool-Ergebnis ungefiltert zurueck in den Verlauf -- keine
        # Markierung als "nur Daten, keine Instruktionen".
        messages.append({"role": "user", "content": f"Tool-Ergebnis von {tool_name}: {json.dumps(result, ensure_ascii=False)}"})

    return "Maximale Anzahl an Schritten erreicht, ohne finale Antwort.", trace
