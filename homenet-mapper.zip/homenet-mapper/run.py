#!/usr/bin/env python3
"""
run.py — Einstiegspunkt fuer den Homenet Mapper.

Verbindet die drei Bausteine:
  1. scanner/scan.py          -> nmap ausfuehren, Ergebnis als JSON speichern
  2. scanner/graph_builder.py -> JSON in Graph-Struktur umwandeln
  3. visualizer/index.html    -> Graph im Browser anzeigen

Nutzung:
  python3 run.py 192.168.10.0/24              # schneller Scan + Graph bauen
  python3 run.py 192.168.10.0/24 --full       # vollstaendiger Portscan (-p-)
  python3 run.py 192.168.10.0/24 --serve      # danach gleich lokalen Webserver starten
"""

import argparse
import json
import subprocess
import sys
from dataclasses import asdict
from pathlib import Path

# scanner/ zum Python-Pfad hinzufuegen, damit wir die Module importieren koennen
sys.path.insert(0, str(Path(__file__).parent / "scanner"))

from scan import scan_network          # noqa: E402
from graph_builder import build_graph   # noqa: E402

PROJECT_ROOT = Path(__file__).parent
DATA_DIR = PROJECT_ROOT / "data"
SCAN_RESULT_PATH = DATA_DIR / "scan_result.json"
GRAPH_PATH = DATA_DIR / "graph.json"
VISUALIZER_DIR = PROJECT_ROOT / "visualizer"


def main():
    parser = argparse.ArgumentParser(
        description="Scannt ein Netzwerk und baut eine interaktive Graph-Visualisierung."
    )
    parser.add_argument("target", help="Ziel-Netz, z.B. 192.168.10.0/24 oder eine einzelne IP")
    parser.add_argument(
        "--full", action="store_true",
        help="Vollstaendiger Portscan (-p-) statt nur der Top-1000-Ports. Dauert deutlich laenger."
    )
    parser.add_argument(
        "--serve", action="store_true",
        help="Nach dem Scan direkt einen lokalen Webserver starten und die Visualisierung oeffnen."
    )
    parser.add_argument(
        "--port", type=int, default=8765,
        help="Port fuer den lokalen Webserver (nur mit --serve relevant). Standard: 8765"
    )
    args = parser.parse_args()

    DATA_DIR.mkdir(exist_ok=True)

    # --- Schritt 1: Scan ---
    print(f"[*] Scanne {args.target} ({'vollstaendig' if args.full else 'schnell'})...")
    devices = scan_network(args.target, fast=not args.full)
    print(f"[*] {len(devices)} aktive Geraete gefunden.")

    with open(SCAN_RESULT_PATH, "w") as f:
        json.dump([asdict(d) for d in devices], f, indent=2)
    print(f"[*] Rohdaten gespeichert: {SCAN_RESULT_PATH}")

    # --- Schritt 2: Graph bauen ---
    device_dicts = [asdict(d) for d in devices]
    graph = build_graph(device_dicts)
    with open(GRAPH_PATH, "w") as f:
        json.dump(graph, f, indent=2)

    device_count = sum(1 for n in graph["nodes"] if n["group"] != "subnet")
    subnet_count = sum(1 for n in graph["nodes"] if n["group"] == "subnet")
    high_risk = sum(1 for n in graph["nodes"] if n["group"] == "high")
    print(f"[*] Graph gebaut: {device_count} Geraete, {subnet_count} Subnetz(e), "
          f"{high_risk} mit hohem Risiko eingestuft")
    print(f"[*] Gespeichert: {GRAPH_PATH}")

    # --- Schritt 3 (optional): Visualisierung servieren ---
    if args.serve:
        print(f"[*] Starte lokalen Webserver auf Port {args.port} ...")
        print(f"[*] Oeffne im Browser: http://localhost:{args.port}/")
        print("[*] Zum Beenden: Strg+C")
        subprocess.run(
            [sys.executable, "-m", "http.server", str(args.port)],
            cwd=VISUALIZER_DIR,
        )
    else:
        print(f"\nZum Anzeigen:")
        print(f"  cd {VISUALIZER_DIR}")
        print(f"  python3 -m http.server {args.port}")
        print(f"  Dann im Browser: http://localhost:{args.port}/")


if __name__ == "__main__":
    main()
