# Homenet Mapper

Ein selbst gebautes Python-Tool zur visuellen Kartierung des eigenen Homelab-Netzwerks — grob inspiriert von Maltego/BloodHound, aber bewusst einfacher gehalten und für ein Heimnetz statt Active Directory gedacht.

## Was es macht

1. Scannt ein Netzwerk (oder mehrere Subnetze/VLANs) mit `nmap` und erkennt aktive Geräte, offene Ports und laufende Dienste.
2. Baut daraus einen Graphen: Geräte als Nodes, Subnetze als Hub-Nodes (zeigt Netzwerksegmentierung — z.B. ob VLANs sauber getrennt sind).
3. Stuft jedes Gerät grob nach Risiko ein (heuristisch anhand bekannter "riskanter" Ports wie Telnet, RDP, SMB — **kein** echter Vulnerability-Scan).
4. Zeigt das Ergebnis als interaktiven Graphen im Browser (vis.js), mit Hover-Tooltips pro Gerät.

## Wichtiger konzeptioneller Unterschied zu BloodHound

BloodHound kennt echte Berechtigungsbeziehungen aus Active Directory (wer kann wen administrieren). Ein reiner `nmap`-Scan im Heimnetz hat das nicht — wir sehen nur, welche Geräte da sind, nicht wer tatsächlich mit wem spricht oder wer wen kontrollieren könnte (das bräuchte echten Netzwerk-Traffic, nicht nur einen Portscan). Die Visualisierung zeigt deshalb bewusst **Topologie + Risiko-Einstufung**, keine erfundenen Angriffspfade.

## Architektur

```
homenet-mapper/
├── scanner/
│   ├── scan.py           # nmap-Aufruf + XML-Parsing -> Device/Service-Objekte
│   └── graph_builder.py  # Device-Liste -> Graph-JSON (Nodes + Edges, Risiko-Heuristik)
├── visualizer/
│   └── index.html        # vis.js-basierte interaktive Darstellung
├── data/                 # scan_result.json, graph.json (werden beim Scan erzeugt)
└── run.py                # CLI-Einstiegspunkt, verbindet alle drei Teile
```

## Voraussetzungen

- Python 3.10+ (nutzt `dataclasses` mit `list[...]`-Syntax)
- `nmap` installiert (`sudo apt install nmap` auf Kali meist schon vorhanden)
- Ein moderner Browser

Keine zusätzlichen Python-Pakete nötig — bewusst nur Standardbibliothek (`subprocess`, `xml.etree.ElementTree`, `json`, `ipaddress`) verwendet, um die Abhängigkeiten minimal zu halten.

## Nutzung

```bash
# ins Projektverzeichnis wechseln (z.B. nach dem Entpacken in ~/Downloads)
cd /home/kali/Downloads/homenet-mapper

# Schneller Scan (Top-1000-Ports) + direkt Visualisierung starten
python3 run.py 192.168.10.0/24 --serve

# Vollständiger Portscan (dauert länger, findet auch ungewöhnliche Ports)
python3 run.py 192.168.10.0/24 --full --serve

# Nur scannen, später manuell anschauen
python3 run.py 192.168.10.0/24
python3 -m http.server 8765        # WICHTIG: im Projekt-Root starten, nicht in visualizer/
# dann im Browser: http://localhost:8765/visualizer/
```

**Wichtig:** Immer per `cd` in den tatsächlichen Projektordner wechseln, bevor `run.py` gestartet wird (z.B. `/home/kali/Downloads/homenet-mapper`) — nicht per Doppelklick aus einem Dateimanager heraus öffnen. Manche Dateimanager/Archiv-Vorschauen entpacken Zip-Dateien sonst in einen temporären, teils schreibgeschützten Sandbox-Ordner (z.B. unter `~/.local/share/...`) statt an den Ort, an dem du sie wirklich haben willst — dann kann `data/scan_result.json` nicht gespeichert werden.

**Wichtig:** Der Webserver muss im Projekt-Root (`homenet-mapper/`) gestartet werden, nicht in `visualizer/` — sonst kann `index.html` die Datei `../data/graph.json` nicht laden (Pythons `http.server` serviert nur Dateien innerhalb seines Start-Ordners). `--serve` macht das automatisch richtig.

**Hinweis:** `nmap`-Scans benötigen je nach Konfiguration erhöhte Rechte für bestimmte Scan-Typen (`sudo python3 run.py ...`, falls Berechtigungsfehler auftreten).

## Bekannte Grenzen (bewusst nicht gelöst, für ehrliche Einordnung)

- Die Risiko-Heuristik schaut nur auf Portnummern, nicht auf tatsächliche Schwachstellen oder CVEs — sie ersetzt keinen echten Vulnerability-Scanner (Nessus/OpenVAS).
- Keine Erkennung tatsächlicher Kommunikationsbeziehungen zwischen Geräten (bräuchte Traffic-Capture/NetFlow statt reinem Portscan).
- OS-Erkennung (`-O`) ist bewusst nicht aktiviert, um Scans schnell und unauffällig zu halten — könnte als Erweiterung ergänzt werden.

## Warum selbst gebaut statt ein fertiges Tool genutzt

Ziel war nicht, ein production-ready Asset-Management-Tool zu bauen, sondern zu verstehen, wie ein Tool wie BloodHound konzeptionell funktioniert — vom rohen Scan-Ergebnis über ein Graph-Datenmodell bis zur interaktiven Visualisierung — und das an einem Netzwerk zu üben, das man selbst kontrolliert.
