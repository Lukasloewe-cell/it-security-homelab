#!/usr/bin/env python3
"""
run.py — Einstiegspunkt fuer den Homenet Mapper.

Verbindet die drei Bausteine:
  1. scanner/scan.py          -> nmap ausfuehren, Ergebnis als JSON speichern
  2. scanner/graph_builder.py -> JSON in Graph-Struktur umwandeln
  3. visualizer/index.html    -> Graph im Browser anzeigen

Nutzung:
  python3 run.py 192.168.10.0/24              # schneller Scan + Graph bauen
  python3 run.py 192.168.10.0/24 --full       # vollstaendiger Portscan (-p-)
  python3 run.py 192.168.10.0/24 --serve      # danach gleich lokalen Webserver starten
"""

import argparse
import json
import shutil
import subprocess
import sys
from dataclasses import asdict
from pathlib import Path

# scanner/ zum Python-Pfad hinzufuegen, damit wir die Module importieren koennen
sys.path.insert(0, str(Path(__file__).parent / "scanner"))

from scan import scan_network          # noqa: E402
from graph_builder import build_graph   # noqa: E402

PROJECT_ROOT = Path(__file__).parent
DATA_DIR = PROJECT_ROOT / "data"
SCAN_RESULT_PATH = DATA_DIR / "scan_result.json"
GRAPH_PATH = DATA_DIR / "graph.json"
VISUALIZER_DIR = PROJECT_ROOT / "visualizer"


def main():
    parser = argparse.ArgumentParser(
        description="Scannt ein Netzwerk und baut eine interaktive Graph-Visualisierung."
    )
    parser.add_argument("target", help="Ziel-Netz, z.B. 192.168.10.0/24 oder eine einzelne IP")
    parser.add_argument(
        "--full", action="store_true",
        help="Vollstaendiger Portscan (-p-) statt nur der Top-1000-Ports. Dauert deutlich laenger."
    )
    parser.add_argument(
        "--no-ping", action="store_true",
        help="Ping-Sweep/Host-Discovery ueberspringen (nmap -Pn) und jede IP direkt scannen. "
             "Wichtig fuer Windows-Hosts: die Windows-Firewall blockt ICMP-Echo standardmaessig, "
             "wodurch nmap solche Hosts sonst faelschlich fuer offline haelt und komplett ueberspringt."
    )
    parser.add_argument(
        "--serve", action="store_true",
        help="Nach dem Scan direkt einen lokalen Webserver starten und die Visualisierung oeffnen."
    )
    parser.add_argument(
        "--port", type=int, default=8765,
        help="Port fuer den lokalen Webserver (nur mit --serve relevant). Standard: 8765"
    )
    args = parser.parse_args()

    DATA_DIR.mkdir(exist_ok=True)

    # --- Vorab-Check: existiert nmap ueberhaupt im PATH? ---
    # Haeufigste Ursache dafuer, dass gar keine JSON entsteht: das Script
    # bricht mit einer Exception ab, BEVOR scan_result.json geschrieben
    # wird (z.B. weil nmap fehlt oder fehlschlaegt). Wir fangen das jetzt
    # explizit ab und geben eine klare Fehlermeldung statt eines rohen
    # Python-Tracebacks.
    if shutil.which("nmap") is None:
        print("[FEHLER] 'nmap' wurde nicht im PATH gefunden.")
        print("         Installieren mit: sudo apt install nmap")
        sys.exit(1)

    # --- Schritt 1: Scan ---
    print(f"[*] Scanne {args.target} ({'vollstaendig' if args.full else 'schnell'})...")
    try:
        devices = scan_network(args.target, fast=not args.full, no_ping=args.no_ping)
    except RuntimeError as e:
        print(f"[FEHLER] nmap-Scan fehlgeschlagen: {e}")
        print("         Haeufige Ursachen:")
        print("         - Fehlende Rechte fuer bestimmte Scan-Techniken -> mit 'sudo' erneut versuchen")
        print("         - Zielangabe falsch/nicht erreichbar (z.B. Tippfehler im Netz/der IP)")
        sys.exit(1)
    except Exception as e:
        print(f"[FEHLER] Unerwarteter Fehler beim Scan: {e}")
        sys.exit(1)

    print(f"[*] {len(devices)} aktive Geraete gefunden.")
    if len(devices) == 0:
        print("[WARNUNG] Keine aktiven Geraete gefunden -- scan_result.json und graph.json")
        print("          werden trotzdem (leer) geschrieben. Moegliche Ursachen: falsches")
        print("          Zielnetz, Geraete blocken ICMP/ARP-Discovery (-> mit '--no-ping'")
        print("          erneut versuchen), oder fehlende Rechte (ggf. mit 'sudo' versuchen).")
    elif not args.no_ping:
        print("[HINWEIS] Falls du Geraete vermisst (z.B. Windows-Hosts, die ICMP-Ping per")
        print("          Firewall standardmaessig blocken), nochmal mit '--no-ping' versuchen --")
        print("          das ueberspringt den Ping-Sweep und scannt jede IP direkt.")

    with open(SCAN_RESULT_PATH, "w") as f:
        json.dump([asdict(d) for d in devices], f, indent=2)
    print(f"[*] Rohdaten gespeichert: {SCAN_RESULT_PATH}")

    # --- Schritt 2: Graph bauen ---
    device_dicts = [asdict(d) for d in devices]
    graph = build_graph(device_dicts)
    with open(GRAPH_PATH, "w") as f:
        json.dump(graph, f, indent=2)

    device_count = sum(1 for n in graph["nodes"] if n["group"] != "subnet")
    subnet_count = sum(1 for n in graph["nodes"] if n["group"] == "subnet")
    high_risk = sum(1 for n in graph["nodes"] if n["group"] == "high")
    print(f"[*] Graph gebaut: {device_count} Geraete, {subnet_count} Subnetz(e), "
          f"{high_risk} mit hohem Risiko eingestuft")
    print(f"[*] Gespeichert: {GRAPH_PATH}")

    # --- Schritt 3 (optional): Visualisierung servieren ---
    # Wichtig: Der Server muss im PROJECT_ROOT laufen, nicht in VISUALIZER_DIR --
    # Pythons http.server serviert nur Dateien INNERHALB seines Start-Ordners
    # (Sicherheitsmassnahme). index.html braucht aber "../data/graph.json",
    # also muessen visualizer/ UND data/ beide unterhalb des Server-Roots liegen.
    if args.serve:
        print(f"[*] Starte lokalen Webserver auf Port {args.port} ...")
        print(f"[*] Oeffne im Browser: http://localhost:{args.port}/visualizer/")
        print("[*] Zum Beenden: Strg+C")
        subprocess.run(
            [sys.executable, "-m", "http.server", str(args.port)],
            cwd=PROJECT_ROOT,
        )
    else:
        print(f"\nZum Anzeigen:")
        print(f"  cd {PROJECT_ROOT}")
        print(f"  python3 -m http.server {args.port}")
        print(f"  Dann im Browser: http://localhost:{args.port}/visualizer/")


if __name__ == "__main__":
    main()
