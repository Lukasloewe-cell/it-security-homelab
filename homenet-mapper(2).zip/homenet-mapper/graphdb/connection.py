"""
connection.py -- duenner Wrapper um den Neo4j-Python-Treiber, plus
Setup-Funktion, die schema.cypher einspielt.

Zugangsdaten ueber Env-Vars (Default passt zum docker-compose.yml):
  NEO4J_URI  = bolt://localhost:7687
  NEO4J_USER = neo4j
  NEO4J_PASS = homenet-graph-pw
"""

import os
from pathlib import Path

from neo4j import GraphDatabase

NEO4J_URI = os.environ.get("NEO4J_URI", "bolt://localhost:7687")
NEO4J_USER = os.environ.get("NEO4J_USER", "neo4j")
NEO4J_PASS = os.environ.get("NEO4J_PASS", "homenet-graph-pw")


def get_driver():
    return GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASS))


def apply_schema():
    """Spielt schema.cypher ein (Constraints + Indizes). Idempotent --
    'IF NOT EXISTS' in jedem Statement, kann beliebig oft laufen."""
    schema_path = Path(__file__).parent / "schema.cypher"
    statements = [
        s.strip()
        for s in schema_path.read_text().split(";")
        if s.strip() and not s.strip().startswith("//")
    ]
    driver = get_driver()
    with driver.session() as session:
        for stmt in statements:
            # Kommentarzeilen innerhalb eines Statements rausfiltern
            clean = "\n".join(
                line for line in stmt.splitlines() if not line.strip().startswith("//")
            ).strip()
            if clean:
                session.run(clean)
    driver.close()
    print("[*] Schema (Constraints + Indizes) angewendet.")


if __name__ == "__main__":
    apply_schema()
