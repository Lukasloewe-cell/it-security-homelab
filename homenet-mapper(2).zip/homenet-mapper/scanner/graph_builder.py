"""
graph_builder.py — baut aus den Scan-Ergebnissen einen Graphen fuer die
Visualisierung.

Wichtiger konzeptioneller Unterschied zu BloodHound:
BloodHound kennt echte Berechtigungs-Kanten (A kann B administrieren,
weil AD das so speichert). Ein reiner nmap-Scan im Heimnetz hat sowas
nicht -- wir sehen nur, welche Geraete da sind und welche Ports offen
sind, nicht wer mit wem tatsaechlich kommuniziert oder wer wen
kontrollieren kann (das wuerde echten Netzwerk-Traffic/NetFlow-Daten
brauchen, nicht nur einen Portscan).

Deshalb baut dieses Modul bewusst eine ehrlichere Darstellung:
- Jedes Subnetz wird ein Hub-Node (zeigt Netzwerksegmentierung --
  z.B. ob dein Kali im selben Netz haengt wie der Windows Server,
  oder ob VLANs sauber trennen)
- Jedes Geraet verbindet sich mit seinem Subnetz-Hub
- Jedes Geraet bekommt eine Risiko-Einstufung basierend auf offenen
  Ports (eine simple Heuristik, KEIN echter Vulnerability-Scan --
  das wird im Code und im Tooltip auch so benannt, um nichts
  vorzutaeuschen)
"""

import json
import ipaddress
from dataclasses import dataclass, field


# Ports, die typischerweise auf ein erhoehtes Risiko hindeuten, wenn sie
# von aussen/aus einem anderen Netzsegment erreichbar sind. Das ist eine
# grobe, manuell kuratierte Liste -- kein Ersatz fuer einen echten
# Vulnerability-Scanner wie Nessus/OpenVAS, aber gut genug fuer eine
# erste visuelle Einordnung im eigenen Lab.
HIGH_RISK_PORTS = {
    21: "FTP (oft Klartext-Login)",
    23: "Telnet (unverschluesselt)",
    445: "SMB (Lateral-Movement-Ziel)",
    3389: "RDP (Brute-Force-Ziel, falls exponiert)",
    5900: "VNC (oft ohne/mit schwachem Passwort)",
}
MEDIUM_RISK_PORTS = {
    22: "SSH (Brute-Force-Ziel bei schwachem Passwort)",
    80: "HTTP (unverschluesselt)",
    3306: "MySQL (sollte selten direkt exponiert sein)",
    5432: "PostgreSQL (sollte selten direkt exponiert sein)",
}

# Grobe Geraete-Typ-Erkennung ueber Vendor/Hostname-Schluesselwoerter -- wie
# die Risiko-Einstufung eine Heuristik, kein zuverlaessiges Fingerprinting
# (das bräuchte z.B. nmap -O, was Root-Rechte + deutlich laengere Scans
# braucht). Reicht aber aus, um der Karte visuell mehr Kontext zu geben.
DEVICE_TYPE_KEYWORDS = {
    "router": ["opnsense", "pfsense", "router", "gateway", "fortinet", "mikrotik", "ubiquiti", "cisco"],
    "server": ["server", "nas", "synology", "proxmox", "esxi", "hypervisor"],
    "printer": ["printer", "hp inc", "epson", "brother", "canon inc"],
    "phone": ["iphone", "android", "samsung electronics", "xiaomi", "huawei", "oneplus"],
    "iot": ["espressif", "raspberry pi", "shelly", "tp-link", "sonos", "philips", "smart"],
}
# Ports, die zusaetzlich (falls Vendor/Hostname nichts hergeben) auf einen
# Geraete-Typ hindeuten.
TYPE_PORT_HINTS = {
    "server": {445, 3389, 5985, 5986},
    "printer": {631, 9100},
}


def guess_device_type(device: dict, is_gateway: bool) -> str:
    """Schaetzt einen groben Geraete-Typ fuer Icon/Darstellung. Reine
    Heuristik -- siehe Modul-Docstring zum generellen Vorbehalt."""
    if is_gateway:
        return "router"

    haystack = f"{device.get('hostname', '')} {device.get('vendor', '')}".lower()
    for dtype, keywords in DEVICE_TYPE_KEYWORDS.items():
        if any(kw in haystack for kw in keywords):
            return dtype

    ports = {svc["port"] for svc in device.get("services", [])}
    for dtype, hint_ports in TYPE_PORT_HINTS.items():
        if ports & hint_ports:
            return dtype

    return "unknown"


def assess_risk(services: list[dict]) -> tuple[str, list[str]]:
    """
    Simple Heuristik: schaut nur auf die PORT-NUMMER, nicht auf
    tatsaechliche Schwachstellen (kein CVE-Abgleich, keine Versions-
    pruefung). Gibt ein Risiko-Level ("high"/"medium"/"low") und eine
    Liste von Begruendungen zurueck, die im Tooltip angezeigt werden.
    """
    reasons = []
    level = "low"

    for svc in services:
        port = svc["port"]
        if port in HIGH_RISK_PORTS:
            reasons.append(f"Port {port}: {HIGH_RISK_PORTS[port]}")
            level = "high"
        elif port in MEDIUM_RISK_PORTS and level != "high":
            reasons.append(f"Port {port}: {MEDIUM_RISK_PORTS[port]}")
            level = "medium"

    return level, reasons


def subnet_id(ip: str) -> str:
    """Gibt das /24-Subnetz einer IP als String zurueck, z.B. '192.168.10.0/24'."""
    network = ipaddress.ip_network(f"{ip}/24", strict=False)
    return str(network)


def build_graph(devices: list[dict]) -> dict:
    """
    Nimmt die Liste der gescannten Geraete (als Dicts, z.B. aus
    scan_result.json) und baut eine Graph-Struktur im Format
    {"nodes": [...], "edges": [...]}, die vis.js direkt einlesen kann.

    Zusaetzlich zur reinen Geraet->Subnetz-Zuordnung werden zwei echte
    Beziehungen erkannt:
    - "bridge"-Kanten zwischen mehreren IPs mit demselben Hostnamen (z.B.
      eine Firewall mit einem Interface/einer IP pro Subnetz -- taucht ohne
      das hier als mehrere unzusammenhaengende Geraete auf, obwohl es
      physisch eine einzige Kiste ist).
    - Gateway-Erkennung (".1"-Adresse je Subnetz), die den Router/die
      Firewall visuell hervorhebt statt sie wie ein gewoehnliches Endgeraet
      zu zeigen.
    """
    nodes = []
    edges = []
    seen_subnets = set()
    hostname_to_ips: dict[str, list[str]] = {}

    for device in devices:
        ip = device["ip"]
        hostname = device.get("hostname", "")
        label = hostname or ip
        services = device.get("services", [])
        risk_level, risk_reasons = assess_risk(services)
        is_gateway = ip.rsplit(".", 1)[-1] == "1"
        device_type = guess_device_type(device, is_gateway)

        # Geraete-Node
        nodes.append({
            "id": ip,
            "label": label,
            "group": risk_level,  # vis.js faerbt Nodes nach "group" ein
            "type": device_type,  # fuer Icon-Auswahl im Frontend
            "port_count": len(services),
            "title": _build_tooltip(device, risk_reasons, device_type, is_gateway),
        })

        if hostname:
            hostname_to_ips.setdefault(hostname, []).append(ip)

        # Subnetz-Hub, falls noch nicht angelegt
        subnet = subnet_id(ip)
        if subnet not in seen_subnets:
            nodes.append({
                "id": subnet,
                "label": subnet,
                "group": "subnet",
            })
            seen_subnets.add(subnet)

        # Kante Geraet -> sein Subnetz
        edges.append({"from": ip, "to": subnet, "kind": "member"})

    # Bridge-Kanten: gleicher Hostname, mehrere IPs/Subnetze = selbes
    # physische Geraet mit mehreren Netzwerk-Interfaces (typisch fuer
    # Router/Firewalls wie OPNsense).
    for hostname, ips in hostname_to_ips.items():
        if len(ips) < 2:
            continue
        for a, b in zip(ips, ips[1:]):
            edges.append({
                "from": a,
                "to": b,
                "kind": "bridge",
                "label": "selbes Gerät",
                "title": f"'{hostname}' hat Interfaces in mehreren Subnetzen (gleicher Hostname erkannt)",
            })

    return {"nodes": nodes, "edges": edges}


def _build_tooltip(device: dict, risk_reasons: list[str], device_type: str, is_gateway: bool) -> str:
    lines = [f"IP: {device['ip']}"]
    if is_gateway:
        lines.append("Rolle: vermutlich Gateway/Router (.1-Adresse)")
    lines.append(f"Typ (Heuristik): {device_type}")
    if device.get("hostname"):
        lines.append(f"Hostname: {device['hostname']}")
    if device.get("vendor"):
        lines.append(f"Hersteller: {device['vendor']}")

    services = device.get("services", [])
    if services:
        lines.append("Offene Ports:")
        for svc in services:
            info = f"  {svc['port']}/{svc['protocol']} - {svc['name']}"
            if svc.get("product"):
                info += f" ({svc['product']} {svc.get('version', '')})".rstrip()
            lines.append(info)
    else:
        lines.append("Keine offenen Ports gefunden")

    if risk_reasons:
        lines.append("Risiko-Hinweise (Heuristik, kein Vuln-Scan):")
        for r in risk_reasons:
            lines.append(f"  - {r}")

    return "\n".join(lines)


if __name__ == "__main__":
    with open("../data/scan_result.json") as f:
        devices = json.load(f)

    graph = build_graph(devices)

    with open("../data/graph.json", "w") as f:
        json.dump(graph, f, indent=2)

    print(f"[*] Graph gebaut: {len(graph['nodes'])} Nodes, {len(graph['edges'])} Edges")
    print("[*] Gespeichert unter ../data/graph.json")
