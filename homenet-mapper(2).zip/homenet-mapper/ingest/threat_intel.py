"""
threat_intel.py -- reichert vorhandene ExternalIP-Nodes mit Reputationsdaten
von AlienVault OTX an (kostenloser Threat-Intel-Feed, kein Vendor-Lock-in
noetig wie bei manchen kommerziellen Angeboten).

Fuer jede ExternalIP im Graphen wird https://otx.alienvault.com/api/v1/
indicators/IPv4/{ip}/general abgefragt. Zentrale Kennzahl ist
"pulse_count": die Anzahl an OTX-"Pulses" (von der Security-Community
gepflegte Threat-Reports), die diese IP erwaehnen. 0 heisst nicht
automatisch "harmlos" -- nur "in dieser Datenbank nicht (noch nicht)
auffaellig".

Env-Vars:
  OTX_API_KEY = <kostenloser API-Key von otx.alienvault.com/api>

Nutzung:
  python3 ingest/threat_intel.py          # alle ExternalIP-Nodes anreichern
  python3 ingest/threat_intel.py 50       # nur die ersten 50 (zum Testen)
"""

import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).parent.parent / "graphdb"))
from connection import get_driver  # noqa: E402

OTX_API_KEY = os.environ.get("OTX_API_KEY", "")
OTX_BASE_URL = "https://otx.alienvault.com/api/v1/indicators/IPv4"

# Hoeflichkeits-Pause zwischen Abfragen -- OTX hat ein Rate-Limit pro
# API-Key; fuer ein Homelab mit wenigen hundert externen IPs ist 1s/Abfrage
# unproblematisch, bei sehr vielen IPs wuerde man eher batchen/cachen.
REQUEST_DELAY_SECONDS = 1.0


def fetch_otx(ip: str) -> dict | None:
    if not OTX_API_KEY:
        print("[FEHLER] OTX_API_KEY ist nicht gesetzt.")
        return None
    try:
        resp = requests.get(
            f"{OTX_BASE_URL}/{ip}/general",
            headers={"X-OTX-API-KEY": OTX_API_KEY},
            timeout=15,
        )
        if resp.status_code == 404:
            return {"pulse_info": {"count": 0, "pulses": []}}
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as exc:
        print(f"[WARNUNG] OTX-Abfrage fuer {ip} fehlgeschlagen: {exc}")
        return None


def _get_all_external_ips() -> list[str]:
    driver = get_driver()
    with driver.session() as session:
        result = session.run("MATCH (e:ExternalIP) RETURN e.ip AS ip")
        ips = [record["ip"] for record in result]
    driver.close()
    return ips


def enrich(limit: int | None = None):
    ips = _get_all_external_ips()
    if limit:
        ips = ips[:limit]
    print(f"[*] {len(ips)} ExternalIP-Nodes werden gegen OTX geprueft.")

    driver = get_driver()
    enriched = 0
    with driver.session() as session:
        for ip in ips:
            data = fetch_otx(ip)
            time.sleep(REQUEST_DELAY_SECONDS)
            if data is None:
                continue

            pulse_info = data.get("pulse_info", {}) or {}
            pulse_count = pulse_info.get("count", 0)
            pulse_names = [p.get("name") for p in (pulse_info.get("pulses") or [])[:3] if p.get("name")]

            session.run(
                """
                MATCH (e:ExternalIP {ip: $ip})
                SET e.pulse_count = $pulse_count,
                    e.pulse_names = $pulse_names,
                    e.reputation = $pulse_count,
                    e.otx_checked_at = $checked_at
                """,
                ip=ip,
                pulse_count=pulse_count,
                pulse_names=pulse_names,
                checked_at=datetime.now(timezone.utc).isoformat(),
            )
            enriched += 1
    driver.close()
    print(f"[*] {enriched} ExternalIP-Nodes mit OTX-Daten angereichert.")


if __name__ == "__main__":
    limit = int(sys.argv[1]) if len(sys.argv) > 1 else None
    enrich(limit=limit)
