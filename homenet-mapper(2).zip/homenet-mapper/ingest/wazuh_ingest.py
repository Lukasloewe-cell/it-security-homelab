"""
wazuh_ingest.py -- holt Alerts aus dem Wazuh Indexer (OpenSearch-REST-API)
und schreibt sie als Alert-Nodes in den Neo4j-Graphen, verknuepft mit dem
Host, der sie ausgeloest hat (ueber agent.ip), und ggf. mit einer externen
IP, falls im Alert eine data.srcip/data.dstip auftaucht, die nicht zum
eigenen Heimnetz gehoert.

Warum Wazuh Indexer statt Wazuh-Manager-API direkt?
Ab Wazuh 4.x landen alle Alerts im "Wazuh Indexer" (ein OpenSearch-Fork) --
das ist die gleiche Datenquelle, die auch das Wazuh-Dashboard anzeigt.
Die REST-API davon ist eine ganz normale Elasticsearch/OpenSearch-Such-
API, kein Wazuh-spezifisches Protokoll -- deshalb reicht hier das
'requests'-Modul statt eines Wazuh-SDKs.

Env-Vars (anpassen an dein Homelab):
  WAZUH_INDEXER_URL = https://<wazuh-host>:9200
  WAZUH_USER        = admin
  WAZUH_PASS         = <dein Passwort>
  WAZUH_VERIFY_TLS  = false   (Standard: false, weil Homelab-Installationen
                                meist ein selbstsigniertes Zertifikat nutzen)
  HOME_NETWORKS     = 192.168.10.0/24,192.168.20.0/24   (deine eigenen
                                Subnetze -- alles ausserhalb gilt als
                                'extern' fuer die ExternalIP-Nodes)
"""

import ipaddress
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests
import urllib3

sys.path.insert(0, str(Path(__file__).parent.parent / "graphdb"))
from connection import get_driver  # noqa: E402

WAZUH_INDEXER_URL = os.environ.get("WAZUH_INDEXER_URL", "https://localhost:9200")
WAZUH_USER = os.environ.get("WAZUH_USER", "admin")
WAZUH_PASS = os.environ.get("WAZUH_PASS", "admin")
WAZUH_VERIFY_TLS = os.environ.get("WAZUH_VERIFY_TLS", "false").lower() == "true"
HOME_NETWORKS = [
    ipaddress.ip_network(n.strip())
    for n in os.environ.get("HOME_NETWORKS", "192.168.0.0/16,10.0.0.0/8").split(",")
    if n.strip()
]

if not WAZUH_VERIFY_TLS:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def is_internal(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return any(addr in net for net in HOME_NETWORKS)


def fetch_alerts(hours: int = 24, size: int = 500) -> list[dict]:
    """Holt die 'size' neuesten Alerts der letzten 'hours' Stunden.

    Hinweis zur Skalierung: fuer ein Homelab reicht ein simpler
    '_search'-Call mit Limit. Bei grossen Datenmengen wuerde man stattdessen
    'search_after'/Scroll-API fuer Pagination nutzen -- hier bewusst
    weggelassen, um das Skript lesbar zu halten.
    """
    since = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    query = {
        "size": size,
        "sort": [{"timestamp": {"order": "desc"}}],
        "query": {"range": {"timestamp": {"gte": since}}},
    }
    resp = requests.post(
        f"{WAZUH_INDEXER_URL}/wazuh-alerts-*/_search",
        json=query,
        auth=(WAZUH_USER, WAZUH_PASS),
        verify=WAZUH_VERIFY_TLS,
        timeout=15,
    )
    resp.raise_for_status()
    hits = resp.json().get("hits", {}).get("hits", [])
    return hits


def ingest(hours: int = 24):
    hits = fetch_alerts(hours=hours)
    print(f"[*] {len(hits)} Alerts aus Wazuh Indexer geholt (letzte {hours}h).")

    driver = get_driver()
    written = 0
    with driver.session() as session:
        for hit in hits:
            src = hit.get("_source", {})
            alert_id = hit.get("_id")
            agent = src.get("agent", {})
            agent_ip = agent.get("ip")
            rule = src.get("rule", {})
            data = src.get("data", {})

            # einige Alert-Typen (Firewall/IDS) tragen die eigentlich
            # relevante IP in data.srcip/data.dstip statt in agent.ip
            candidate_ips = [
                ip for ip in [agent_ip, data.get("srcip"), data.get("dstip")] if ip
            ]
            external_ip = next((ip for ip in candidate_ips if not is_internal(ip)), None)

            session.run(
                """
                MERGE (a:Alert {id: $id})
                SET a.rule_id = $rule_id,
                    a.description = $description,
                    a.severity = $severity,
                    a.timestamp = $timestamp
                """,
                id=alert_id,
                rule_id=rule.get("id"),
                description=rule.get("description"),
                severity=rule.get("level"),
                timestamp=src.get("timestamp"),
            )

            if agent_ip:
                session.run(
                    """
                    MERGE (h:Host {ip: $ip})
                    ON CREATE SET h.hostname = $hostname
                    WITH h
                    MATCH (a:Alert {id: $id})
                    MERGE (h)-[:TRIGGERED]->(a)
                    """,
                    ip=agent_ip,
                    hostname=agent.get("name", ""),
                    id=alert_id,
                )

            if external_ip:
                session.run(
                    """
                    MERGE (e:ExternalIP {ip: $ip})
                    WITH e
                    MATCH (a:Alert {id: $id})
                    MERGE (a)-[:INVOLVES]->(e)
                    """,
                    ip=external_ip,
                    id=alert_id,
                )

            written += 1
    driver.close()
    print(f"[*] {written} Alerts in den Graphen geschrieben.")


if __name__ == "__main__":
    import sys

    hours = int(sys.argv[1]) if len(sys.argv) > 1 else 24
    ingest(hours=hours)
