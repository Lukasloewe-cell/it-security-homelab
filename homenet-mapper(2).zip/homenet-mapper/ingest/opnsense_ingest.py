"""
opnsense_ingest.py -- holt Firewall-Log-Eintraege direkt von der OPNsense-API
und schreibt sie als COMMUNICATED_WITH-Beziehungen zwischen Host und
ExternalIP in den Graphen. Das ist die Antwort auf die urspruengliche Frage
("wer redet eigentlich mit wem, auch nach draussen") -- Wazuh-Alerts zeigen
nur, was als verdaechtig *erkannt* wurde, OPNsense-Firewall-Logs zeigen
*jede* Verbindung, die durch die Firewall lief (erlaubt oder geblockt).

Warum eigenes Skript statt ueber Wazuh?
Du hast dich bewusst fuer den direkten API-Weg entschieden statt OPNsense-
Logs erst per Syslog nach Wazuh zu schicken. Vorteil: unabhaengig von der
Wazuh-Pipeline, einfacher zu debuggen. Nachteil: zwei getrennte Quellen
(Wazuh fuer Alerts, OPNsense fuer rohen Traffic) statt einer -- wenn du
spaeter merkst, dass dir das zu viele Baustellen sind, waere "alles ueber
Wazuh-Syslog" die Alternative gewesen.

WICHTIG -- API-Felder pruefen:
OPNsense aendert die genauen Feldnamen der Firewall-Log-API zwischen
Versionen. Dieses Skript geht defensiv vor (mehrere moegliche Feldnamen
pro Wert), aber verifiziere den tatsaechlichen Endpunkt/die Feldnamen
deiner Version unter System > Firmware > Status (API-Dokumentation) oder
mit einem einzelnen curl-Testaufruf, bevor du dich auf die Daten verlaesst:

  curl -k -u "<API_KEY>:<API_SECRET>" \\
    -H "Content-Type: application/json" \\
    -d '{"limit": 5}' \\
    https://<opnsense-host>/api/diagnostics/firewall/log_filter

Wenn der Endpunkt oder die Feldnamen bei dir anders heissen, pass FIELD_*
unten an -- der Rest des Skripts (Graph-Schreiblogik) bleibt gleich.

Env-Vars:
  OPNSENSE_URL          = https://<opnsense-host>          (ohne /api)
  OPNSENSE_API_KEY      = <API-Key aus System > Access > Users>
  OPNSENSE_API_SECRET   = <zugehoeriges API-Secret>
  OPNSENSE_VERIFY_TLS   = false   (Standard: false, selbstsigniertes Zertifikat)
  HOME_NETWORKS         = 192.168.10.0/24,192.168.20.0/24   (wie bei wazuh_ingest.py)
"""

import ipaddress
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import requests
import urllib3

sys.path.insert(0, str(Path(__file__).parent.parent / "graphdb"))
from connection import get_driver  # noqa: E402

OPNSENSE_URL = os.environ.get("OPNSENSE_URL", "https://localhost").rstrip("/")
OPNSENSE_API_KEY = os.environ.get("OPNSENSE_API_KEY", "")
OPNSENSE_API_SECRET = os.environ.get("OPNSENSE_API_SECRET", "")
OPNSENSE_VERIFY_TLS = os.environ.get("OPNSENSE_VERIFY_TLS", "false").lower() == "true"
HOME_NETWORKS = [
    ipaddress.ip_network(n.strip())
    for n in os.environ.get("HOME_NETWORKS", "192.168.0.0/16,10.0.0.0/8").split(",")
    if n.strip()
]

if not OPNSENSE_VERIFY_TLS:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def is_internal(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return any(addr in net for net in HOME_NETWORKS)


def _first(row: dict, *keys):
    """Gibt den ersten vorhandenen, nicht-leeren Wert unter mehreren
    moeglichen Feldnamen zurueck -- Pufferung gegen API-Versionsunterschiede."""
    for k in keys:
        v = row.get(k)
        if v:
            return v
    return None


def fetch_log_entries(limit: int = 1000) -> list[dict]:
    """Holt die letzten 'limit' Firewall-Log-Eintraege. Hinweis zur
    Skalierung: wie bei wazuh_ingest.py bewusst ohne Pagination/Scroll --
    fuer ein Homelab-Volumen reicht ein einzelner Abruf der juengsten
    Eintraege."""
    resp = requests.post(
        f"{OPNSENSE_URL}/api/diagnostics/firewall/log_filter",
        json={"limit": limit},
        auth=(OPNSENSE_API_KEY, OPNSENSE_API_SECRET),
        verify=OPNSENSE_VERIFY_TLS,
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()
    # Je nach Version liefert die API die Liste direkt oder unter "rows"/"data"
    if isinstance(data, dict):
        return data.get("rows") or data.get("data") or []
    return data


def ingest(limit: int = 1000):
    entries = fetch_log_entries(limit=limit)
    print(f"[*] {len(entries)} Firewall-Log-Eintraege von OPNsense geholt.")

    driver = get_driver()
    written = 0
    skipped_both_internal_or_external = 0
    with driver.session() as session:
        for row in entries:
            src_ip = _first(row, "sourceip", "src", "source")
            dst_ip = _first(row, "destinationip", "dst", "destination")
            if not src_ip or not dst_ip:
                continue

            src_internal = is_internal(src_ip)
            dst_internal = is_internal(dst_ip)

            # Uns interessiert hier nur "unser Host redet mit draussen" --
            # rein internen oder rein externen Traffic lassen wir aus
            # (gleiche bewusste Einschraenkung wie in wazuh_ingest.py).
            if src_internal == dst_internal:
                skipped_both_internal_or_external += 1
                continue

            host_ip, external_ip = (src_ip, dst_ip) if src_internal else (dst_ip, src_ip)

            port = _first(row, "destinationport", "dstport", "dport") or "?"
            protocol = _first(row, "protoname", "protocol", "proto") or "?"
            action = _first(row, "action") or "?"
            timestamp = _first(row, "time", "__timestamp__") or datetime.now(timezone.utc).isoformat()

            session.run(
                """
                MERGE (h:Host {ip: $host_ip})
                MERGE (e:ExternalIP {ip: $external_ip})
                MERGE (h)-[r:COMMUNICATED_WITH]->(e)
                ON CREATE SET
                    r.first_seen = $timestamp,
                    r.last_seen = $timestamp,
                    r.count = 1,
                    r.ports = [$port],
                    r.protocols = [$protocol],
                    r.last_action = $action
                ON MATCH SET
                    r.last_seen = $timestamp,
                    r.count = r.count + 1,
                    r.ports = CASE WHEN $port IN r.ports THEN r.ports ELSE r.ports + $port END,
                    r.protocols = CASE WHEN $protocol IN r.protocols THEN r.protocols ELSE r.protocols + $protocol END,
                    r.last_action = $action
                """,
                host_ip=host_ip,
                external_ip=external_ip,
                port=str(port),
                protocol=str(protocol),
                action=str(action),
                timestamp=str(timestamp),
            )
            written += 1
    driver.close()
    print(f"[*] {written} Host<->ExternalIP-Verbindungen geschrieben "
          f"({skipped_both_internal_or_external} rein interne/externe Eintraege ausgelassen).")


if __name__ == "__main__":
    limit = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
    ingest(limit=limit)
