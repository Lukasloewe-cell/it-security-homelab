"""
import_scan.py -- importiert data/scan_result.json (das Ergebnis des
Phase-1-nmap-Scans aus run.py) als Host-Nodes in den Neo4j-Graphen.

Das ist die Bruecke zwischen Phase 1 und Phase 2: der nmap-Scan liefert
die "Basis-Identitaet" jedes Hosts (Hostname, MAC, Vendor, offene Ports),
wazuh_ingest.py haengt spaeter Alerts an genau diese Host-Nodes (gleiche
IP = gleicher Knoten, dank MERGE statt CREATE).

Nutzung:
  cd homenet-mapper
  python3 ingest/import_scan.py
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "graphdb"))
from connection import get_driver  # noqa: E402

PROJECT_ROOT = Path(__file__).parent.parent
SCAN_RESULT_PATH = PROJECT_ROOT / "data" / "scan_result.json"


def import_scan():
    if not SCAN_RESULT_PATH.exists():
        print(f"[FEHLER] {SCAN_RESULT_PATH} nicht gefunden -- erst 'python3 run.py <netz>' laufen lassen.")
        return

    with open(SCAN_RESULT_PATH) as f:
        devices = json.load(f)

    driver = get_driver()
    with driver.session() as session:
        for device in devices:
            session.run(
                """
                MERGE (h:Host {ip: $ip})
                SET h.hostname = $hostname,
                    h.mac = $mac,
                    h.vendor = $vendor,
                    h.open_ports = $open_ports
                """,
                ip=device["ip"],
                hostname=device.get("hostname", ""),
                mac=device.get("mac", ""),
                vendor=device.get("vendor", ""),
                open_ports=[svc["port"] for svc in device.get("services", [])],
            )
    driver.close()
    print(f"[*] {len(devices)} Hosts aus dem nmap-Scan in den Graphen importiert.")


if __name__ == "__main__":
    import_scan()
