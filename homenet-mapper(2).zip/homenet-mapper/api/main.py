"""
main.py -- FastAPI-Backend, das den Neo4j-Graphen als JSON fuers Frontend
ausliefert (Cytoscape.js-kompatibles Format: {"nodes": [...], "edges": [...]}).

Warum ueberhaupt eine eigene API statt dem Frontend direkt Cypher-Queries
schicken zu lassen? Zwei Gruende: (1) Neo4j-Zugangsdaten sollen nicht im
Browser landen, (2) das Frontend soll nur "gib mir den Graphen der letzten
X Stunden" sagen muessen, nicht selbst Cypher koennen -- die Query-Logik
gehoert ins Backend.

Start:
  cd homenet-mapper
  uvicorn api.main:app --reload --port 8000
"""

import sys
from pathlib import Path

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware

sys.path.insert(0, str(Path(__file__).parent.parent / "graphdb"))
from connection import get_driver  # noqa: E402

app = FastAPI(title="Homenet Graph API")

# CORS offen fuer lokale Entwicklung (Frontend laeuft auf anderem Port) --
# in einer echten Deployment-Situation wuerde man das auf die konkrete
# Frontend-Origin einschraenken.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _host_node(h):
    return {
        "data": {
            "id": f"host:{h['ip']}",
            "label": h.get("hostname") or h["ip"],
            "kind": "host",
            "ip": h["ip"],
            "open_ports": h.get("open_ports", []),
        }
    }


def _ext_node(e):
    return {
        "data": {
            "id": f"ext:{e['ip']}",
            "label": e["ip"],
            "kind": "external_ip",
            "reputation": e.get("reputation"),
            "pulse_count": e.get("pulse_count"),
            "pulse_names": e.get("pulse_names"),
        }
    }


@app.get("/graph")
def get_graph(hours: int = Query(24, description="Nur Alerts/Traffic der letzten N Stunden beruecksichtigen")):
    """Liefert den kompletten sichtbaren Graphen: alle Hosts, alle Alerts
    der letzten 'hours' Stunden mitsamt den externen IPs daraus, sowie den
    direkten OPNsense-Traffic (COMMUNICATED_WITH) im selben Zeitfenster."""
    driver = get_driver()
    nodes = {}
    edges = []

    with driver.session() as session:
        # Teil 1: Hosts + ihre Wazuh-Alerts (im Zeitfenster) + externe IPs daraus.
        # datetime(a.timestamp) konvertiert den gespeicherten ISO-String in
        # einen echten Neo4j-Zeitwert -- ohne das wuerde der Vergleich mit
        # 'datetime() - duration(...)' nicht zuverlaessig funktionieren.
        result = session.run(
            """
            MATCH (h:Host)
            OPTIONAL MATCH (h)-[:TRIGGERED]->(a:Alert)
              WHERE a.timestamp IS NOT NULL
                AND datetime(a.timestamp) >= datetime() - duration({hours: $hours})
            OPTIONAL MATCH (a)-[:INVOLVES]->(e:ExternalIP)
            RETURN h, a, e
            """,
            hours=hours,
        )
        for record in result:
            h, a, e = record["h"], record["a"], record["e"]
            host_id = f"host:{h['ip']}"
            if host_id not in nodes:
                nodes[host_id] = _host_node(h)

            if a is not None:
                alert_id = f"alert:{a['id']}"
                if alert_id not in nodes:
                    nodes[alert_id] = {
                        "data": {
                            "id": alert_id,
                            "label": a.get("description", "Alert"),
                            "kind": "alert",
                            "severity": a.get("severity"),
                            "timestamp": a.get("timestamp"),
                        }
                    }
                edges.append({
                    "data": {
                        "id": f"{host_id}->{alert_id}",
                        "source": host_id,
                        "target": alert_id,
                        "kind": "triggered",
                    }
                })

                if e is not None:
                    ext_id = f"ext:{e['ip']}"
                    if ext_id not in nodes:
                        nodes[ext_id] = _ext_node(e)
                    edges.append({
                        "data": {
                            "id": f"{alert_id}->{ext_id}",
                            "source": alert_id,
                            "target": ext_id,
                            "kind": "involves",
                        }
                    })

        # Teil 2: direkter OPNsense-Traffic (unabhaengig davon, ob ein
        # Wazuh-Alert dazu existiert) -- zeigt auch unauffaelligen/erlaubten
        # Verkehr, nicht nur das, was als Alert erkannt wurde.
        result2 = session.run(
            """
            MATCH (h:Host)-[c:COMMUNICATED_WITH]->(e:ExternalIP)
              WHERE c.last_seen IS NOT NULL
                AND datetime(c.last_seen) >= datetime() - duration({hours: $hours})
            RETURN h, c, e
            """,
            hours=hours,
        )
        for record in result2:
            h, c, e = record["h"], record["c"], record["e"]
            host_id = f"host:{h['ip']}"
            if host_id not in nodes:
                nodes[host_id] = _host_node(h)
            ext_id = f"ext:{e['ip']}"
            if ext_id not in nodes:
                nodes[ext_id] = _ext_node(e)
            edges.append({
                "data": {
                    "id": f"{host_id}->{ext_id}:comm",
                    "source": host_id,
                    "target": ext_id,
                    "kind": "communicated_with",
                    "ports": c.get("ports"),
                    "protocols": c.get("protocols"),
                    "count": c.get("count"),
                    "last_action": c.get("last_action"),
                }
            })

    driver.close()
    return {"nodes": list(nodes.values()), "edges": edges}


@app.get("/health")
def health():
    return {"status": "ok"}
