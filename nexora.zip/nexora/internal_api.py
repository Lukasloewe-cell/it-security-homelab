"""
internal_api.py — die "interne" NEXORA-Admin-Microservice.

Konzept: In echten Firmen gibt es oft interne Services, die bewusst NICHT
von aussen erreichbar sind (kein offener Port, keine Firewall-Freigabe) --
das Team verlaesst sich darauf, dass "niemand von aussen rankommt" als
einzige Schutzmassnahme (kein zusaetzlicher Auth-Check noetig, dachte man).

Dieser Service laeuft deshalb ausschliesslich auf 127.0.0.1:9090 -- vom
Netzwerk aus (auch nicht von Kali auf OPT1) ist er NICHT erreichbar. Die
einzige Moeglichkeit, ihn trotzdem anzusprechen: ueber eine SSRF-Luecke im
Hauptservice (app.py), der ja selbst auf localhost laeuft und deshalb
127.0.0.1:9090 problemlos erreichen kann.

Der X-Internal-Key-Header ist die einzige Zugriffskontrolle -- der Key ist
absichtlich in einem JS-Bundle des Hauptservice "vergessen" worden (siehe
static/js/vendor/analytics.bundle.js).
"""

import sqlite3
from pathlib import Path
from flask import Flask, request, jsonify

DB_PATH = Path(__file__).parent / "nexora.db"
INTERNAL_KEY = "nxr_internal_8f2c91a07e4b4d5fa9c0"

app = Flask(__name__)


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


@app.route("/internal/health")
def health():
    # Bewusst OHNE Key-Pruefung erreichbar -- Health-Checks sollen von
    # Monitoring-Systemen ohne Auth abfragbar sein. Verraet aber schon,
    # dass hier ueberhaupt ein interner Service laeuft (nuetzlich beim
    # Durchprobieren von Ports per SSRF).
    return jsonify({"service": "nexora-internal-admin", "status": "ok"})


@app.route("/internal/admin/promote")
def promote():
    # --- Luecke (Teil 2 der Kette): schwache interne Authentifizierung ---
    # Absichtlich als GET mit Query-Parametern gebaut (nicht POST+JSON),
    # weil eine simple SSRF-Luecke im Hauptservice meist nur GET-Requests
    # weiterleiten kann -- genau das macht diesen Endpunkt ueberhaupt
    # erreichbar fuer den Angriffspfad.
    key = request.args.get("key", "")
    username = request.args.get("username", "")

    if key != INTERNAL_KEY:
        return jsonify({"error": "invalid internal key"}), 403
    if not username:
        return jsonify({"error": "username required"}), 400

    conn = get_db()
    user = conn.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
    if user is None:
        conn.close()
        return jsonify({"error": "user not found"}), 404

    conn.execute("UPDATE users SET role = 'admin' WHERE id = ?", (user["id"],))
    conn.commit()
    conn.close()
    return jsonify({"status": "promoted", "username": username, "role": "admin"})


if __name__ == "__main__":
    # NUR auf 127.0.0.1 binden -- das ist die eigentliche "Firewall" dieses
    # Service, bewusst NICHT 0.0.0.0. Port 9090, bewusst anders als der
    # Hauptservice (8082), damit man ihn beim Durchprobieren per SSRF auch
    # wirklich erst finden muss.
    app.run(host="127.0.0.1", port=9090, debug=False)
