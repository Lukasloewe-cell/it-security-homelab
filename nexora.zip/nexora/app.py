"""
app.py — NEXORA Cloud Intelligence, Hauptservice.

Fiktive Firma, fiktives Produkt (eine "KI-gestuetzte Cloud-Analytics-
Plattform"). Absichtlich verwundbar, als Uebungsziel fuers eigene Homelab.

Bewusst eingebaute Luecken (Details + Exploit-Walkthrough in README.md):
  1. SSRF in der "Datenquelle verbinden"-Vorschau
  2. Path Traversal beim Report-Download
  3. Mass Assignment in der Account-Settings-API
  4. Stored XSS in Projekt-Kommentaren
  5. IDOR bei der Rechnungs-API
  6. Geleakter interner API-Key in einem JS-Bundle (Baustein fuer Luecke 1)

Bewusst NICHT enthalten (auf Wunsch): SQL Injection, Command Injection,
Cookie-/Session-Signing-Angriffe. Alle DB-Queries sind parametrisiert,
Flask-Sessions werden ganz normal (nicht als Angriffsziel) genutzt.
"""

import hashlib
import os
import sqlite3
from pathlib import Path

import requests
from flask import Flask, g, redirect, render_template, request, session, url_for

BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "nexora.db"
REPORTS_DIR = BASE_DIR / "reports"

app = Flask(__name__)
app.secret_key = os.urandom(24)  # zufaellig, kein Leak/Angriffsziel diesmal


def hash_pw(s: str) -> str:
    return hashlib.md5(s.encode()).hexdigest()


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def current_user():
    if "user_id" not in session:
        return None
    return get_db().execute(
        "SELECT * FROM users WHERE id = ?", (session["user_id"],)
    ).fetchone()


def login_required(view):
    from functools import wraps

    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped


# ---------------------------------------------------------------- Öffentlich

@app.route("/")
def landing():
    return render_template("landing.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        existing = db.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
        if not username or not password:
            error = "Benutzername und Passwort erforderlich."
        elif existing:
            error = "Benutzername bereits vergeben."
        else:
            db.execute(
                "INSERT INTO users (username, password, role, plan, credits) VALUES (?, ?, 'user', 'free', 50)",
                (username, hash_pw(password)),
            )
            db.commit()
            return redirect(url_for("login"))
    return render_template("register.html", error=error)


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        row = db.execute(
            "SELECT * FROM users WHERE username = ? AND password = ?",
            (username, hash_pw(password)),
        ).fetchone()
        if row:
            session["user_id"] = row["id"]
            return redirect(url_for("dashboard"))
        error = "Login fehlgeschlagen."
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("landing"))


# -------------------------------------------------------------- Eingeloggt

@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    db = get_db()
    projects = db.execute(
        "SELECT * FROM projects WHERE user_id = ? ORDER BY id DESC", (user["id"],)
    ).fetchall()
    return render_template("dashboard.html", user=user, projects=projects)


@app.route("/project/<int:project_id>", methods=["GET", "POST"])
@login_required
def project_detail(project_id):
    user = current_user()
    db = get_db()
    project = db.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    if project is None:
        return render_template("project.html", project=None, comments=[], user=user), 404

    if request.method == "POST":
        body = request.form.get("body", "")
        if body.strip():
            # --- Lücke 4: Stored XSS ---
            # Kommentar wird 1:1 gespeichert und im Template ungeescaped
            # ausgegeben (|safe), kein Sanitizing. Jeder, der das Projekt
            # spaeter oeffnet (auch der Owner!), bekommt den Payload
            # ausgefuehrt.
            db.execute(
                "INSERT INTO comments (project_id, author, body) VALUES (?, ?, ?)",
                (project_id, user["username"], body),
            )
            db.commit()
        return redirect(url_for("project_detail", project_id=project_id))

    comments = db.execute(
        "SELECT * FROM comments WHERE project_id = ? ORDER BY id ASC", (project_id,)
    ).fetchall()
    return render_template("project.html", project=project, comments=comments, user=user)


@app.route("/account", methods=["GET"])
@login_required
def account():
    user = current_user()
    own_invoice = get_db().execute(
        "SELECT id FROM invoices WHERE user_id = ? ORDER BY id LIMIT 1", (user["id"],)
    ).fetchone()
    return render_template("account.html", user=user, own_invoice_id=own_invoice["id"] if own_invoice else None)


@app.route("/api/account/update", methods=["POST"])
@login_required
def api_account_update():
    # --- Lücke 3: Mass Assignment ---
    # Der JSON-Body wird ohne Feld-Whitelist direkt in ein UPDATE
    # uebernommen. Gedacht ist das Formular nur fuer "display_name" --
    # wer aber zusaetzliche Felder (z.B. "role", "credits", "plan") im
    # JSON-Body mitschickt, kann sie trotzdem setzen, weil der Server nicht
    # prueft, welche Felder ueberhaupt erlaubt sein sollen.
    data = request.get_json(silent=True) or {}
    user = current_user()
    db = get_db()

    allowed_columns = {"username", "role", "plan", "credits"}  # Tabellen-Spalten
    # ACHTUNG (bewusst so gelassen): "allowed_columns" filtert nur, WELCHE
    # SPALTEN ueberhaupt existieren -- nicht, welche der eingeloggte User
    # selbst aendern duerfen sollte. role/plan/credits landen hier mit
    # drin, obwohl das Formular im UI nur "display_name" anbietet.
    updates = {k: v for k, v in data.items() if k in allowed_columns}
    if not updates:
        return {"error": "keine gueltigen Felder"}, 400

    set_clause = ", ".join(f"{k} = ?" for k in updates)
    values = list(updates.values()) + [user["id"]]
    db.execute(f"UPDATE users SET {set_clause} WHERE id = ?", values)
    db.commit()
    return {"status": "updated", "fields": list(updates.keys())}


@app.route("/api/invoices/<int:invoice_id>")
@login_required
def api_invoice(invoice_id):
    # --- Lücke 5: IDOR ---
    # Es wird nur geprueft, ob ueberhaupt jemand eingeloggt ist -- nicht,
    # ob die Rechnung auch dem eingeloggten User gehoert.
    db = get_db()
    row = db.execute(
        "SELECT i.*, u.username AS owner FROM invoices i "
        "JOIN users u ON u.id = i.user_id WHERE i.id = ?",
        (invoice_id,),
    ).fetchone()
    if row is None:
        return {"error": "not found"}, 404
    return {
        "id": row["id"],
        "owner": row["owner"],
        "amount_eur": row["amount_eur"],
        "description": row["description"],
    }


@app.route("/reports/download")
@login_required
def reports_download():
    # --- Lücke 2: Path Traversal ---
    # Der Dateiname aus dem Query-Parameter wird naiv per os.path.join
    # mit dem Report-Verzeichnis zusammengebaut -- ".."-Sequenzen werden
    # nicht herausgefiltert, dadurch kann man aus REPORTS_DIR ausbrechen.
    filename = request.args.get("file", "")
    full_path = os.path.join(REPORTS_DIR, filename)
    if not os.path.isfile(full_path):
        return {"error": "Datei nicht gefunden"}, 404
    with open(full_path, "r", errors="replace") as f:
        content = f.read()
    return f"<pre>{content}</pre>"


@app.route("/datasource", methods=["GET", "POST"])
@login_required
def datasource():
    preview = None
    error = None
    if request.method == "POST":
        url = request.form.get("url", "").strip()
        if url:
            # --- Lücke 1: SSRF ---
            # Die URL kommt direkt vom Nutzer und wird ohne jede
            # Einschraenkung (kein Allowlist fuer Hosts, kein Blocken von
            # 127.0.0.1/interne Adressen) serverseitig abgerufen. Der
            # Server selbst kann aber Dinge erreichen, die von aussen
            # (auch von Kali auf OPT1) nicht erreichbar sind -- z.B.
            # 127.0.0.1:9090.
            try:
                resp = requests.get(url, timeout=4)
                preview = resp.text[:3000]
            except Exception as exc:
                error = f"Abruf fehlgeschlagen: {exc}"
    return render_template("datasource.html", preview=preview, error=error)


@app.route("/admin")
@login_required
def admin():
    user = current_user()
    if user["role"] != "admin":
        return render_template("admin.html", authorized=False, users=None), 403
    db = get_db()
    users = db.execute("SELECT id, username, role, plan, credits FROM users ORDER BY id").fetchall()
    return render_template("admin.html", authorized=True, users=users)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8082, debug=False)
