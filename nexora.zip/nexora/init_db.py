"""
init_db.py — legt die SQLite-Datenbank fuer NEXORA neu an.

Alle Queries im gesamten Projekt laufen ausschliesslich parametrisiert
(sqlite3 mit "?"-Platzhaltern) -- diesmal bewusst KEINE SQL Injection als
Luecke, siehe README.
"""

import hashlib
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "nexora.db"


def hash_pw(s: str) -> str:
    # Wie beim Elster-Portal: absichtlich simpel (MD5, kein Salt) gehalten,
    # damit der Fokus auf den eigentlichen Luecken dieses Projekts bleibt,
    # nicht auf Passwort-Hashing-Best-Practices.
    return hashlib.md5(s.encode()).hexdigest()


USERS = [
    # (username, password_klartext, role, plan, credits)
    ("admin", "N3x0ra_R00t!", "admin", "enterprise", 999999),
    ("l.weiss", "sommer2025", "user", "free", 120),
    ("t.bauer", "passwort456", "user", "pro", 2400),
    ("k.fischer", "quantensprung", "user", "free", 85),
]

PROJECTS = [
    # (owner_username, name, description)
    ("l.weiss", "Marktanalyse Q4", "Automatisierte Trendanalyse fuer den Heimatmarkt."),
    ("l.weiss", "Sentiment-Pipeline", "NLP-Pipeline fuer Kundenfeedback-Auswertung."),
    ("t.bauer", "Supply-Chain-Forecast", "Vorhersagemodell fuer Lieferkettenengpaesse."),
    ("k.fischer", "Interner Chatbot-Prototyp", "Erstversion eines internen Support-Bots."),
]

INVOICES = [
    # (owner_username, amount_eur, description)
    ("l.weiss", 0.00, "Free Tier -- keine Abrechnung"),
    ("t.bauer", 249.00, "NEXORA Pro -- Oktober 2026"),
    ("k.fischer", 0.00, "Free Tier -- keine Abrechnung"),
    ("admin", 14999.00, "NEXORA Enterprise -- Jahreslizenz 2026 (vertraulich)"),
]


def main():
    if DB_PATH.exists():
        DB_PATH.unlink()

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            plan TEXT NOT NULL DEFAULT 'free',
            credits INTEGER NOT NULL DEFAULT 0
        )
    """)
    cur.execute("""
        CREATE TABLE projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)
    cur.execute("""
        CREATE TABLE comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            author TEXT NOT NULL,
            body TEXT NOT NULL,
            FOREIGN KEY (project_id) REFERENCES projects (id)
        )
    """)
    cur.execute("""
        CREATE TABLE invoices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            amount_eur REAL NOT NULL,
            description TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)

    user_ids = {}
    for username, password, role, plan, credits in USERS:
        cur.execute(
            "INSERT INTO users (username, password, role, plan, credits) VALUES (?, ?, ?, ?, ?)",
            (username, hash_pw(password), role, plan, credits),
        )
        user_ids[username] = cur.lastrowid

    project_ids = {}
    for owner, name, desc in PROJECTS:
        cur.execute(
            "INSERT INTO projects (user_id, name, description) VALUES (?, ?, ?)",
            (user_ids[owner], name, desc),
        )
        project_ids[name] = cur.lastrowid

    cur.execute(
        "INSERT INTO comments (project_id, author, body) VALUES (?, ?, ?)",
        (project_ids["Marktanalyse Q4"], "t.bauer", "Sieht gut aus, koennen wir das auf Q1 2027 erweitern?"),
    )
    cur.execute(
        "INSERT INTO comments (project_id, author, body) VALUES (?, ?, ?)",
        (project_ids["Sentiment-Pipeline"], "l.weiss", "Erste Ergebnisse sind vielversprechend."),
    )

    for owner, amount, desc in INVOICES:
        cur.execute(
            "INSERT INTO invoices (user_id, amount_eur, description) VALUES (?, ?, ?)",
            (user_ids[owner], amount, desc),
        )

    conn.commit()
    conn.close()

    print(f"[*] Datenbank angelegt unter {DB_PATH}")
    print("[*] Testlogins (normale, nicht-exploitierte Accounts):")
    for username, password, role, plan, credits in USERS:
        print(f"    {username} / {password}  (role={role}, plan={plan})")


if __name__ == "__main__":
    main()
