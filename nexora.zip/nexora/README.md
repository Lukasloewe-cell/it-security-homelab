# NEXORA Cloud Intelligence — absichtlich verwundbare SaaS-Plattform

Eine fiktive "KI-gestützte Cloud-Analytics-Plattform" (NEXORA Dynamics) als
Übungsziel fürs eigene Homelab. Bewusst **ohne** SQL Injection, Command
Injection oder Cookie-/Session-Signing-Angriffe — stattdessen eine Kette aus
moderneren Lücken (SSRF, Path Traversal, Mass Assignment, Stored XSS, IDOR),
die sich zu einem echten Angriffspfad verketten lassen.

**Nur für dein eigenes, isoliertes Lab-Netz. Nicht in ein Netz stellen, das
nicht vollständig unter deiner Kontrolle ist.**

## Das Ziel

Am Ende der Kette steht ein voller Admin-Zugriff (`/admin`) über einen ganz
normal registrierten, nicht privilegierten Account — ganz ohne SQLi, ganz
ohne das Passwort eines echten Admins zu kennen.

## Deployment auf der Ubuntu-VM

Zwei Prozesse laufen parallel: der öffentliche Hauptservice (Port 8082) und
ein **interner** Admin-Microservice (Port 9090, **nur** `127.0.0.1`, von
außen nicht erreichbar — der eigentliche Twist der Kette).

### Schnellstart (manuell, zum Testen)

```bash
cd nexora
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 init_db.py

# In zwei Terminals (oder mit & im Hintergrund):
python3 internal_api.py &   # 127.0.0.1:9090
python3 app.py              # 0.0.0.0:8082
```

### Produktiv als systemd-Services (empfohlen — läuft dauerhaft, Logs gehen
automatisch an journald und damit direkt in Wazuh)

```bash
# Einmalig: Unit-Dateien installieren (Pfade/User in den .service-Dateien
# ggf. anpassen, falls dein Projekt nicht unter /home/<user>/nexora liegt)
sudo cp deploy/nexora.service /etc/systemd/system/
sudo cp deploy/nexora-internal.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now nexora-internal@<dein-linux-user>.service
sudo systemctl enable --now nexora@<dein-linux-user>.service
```

Prüfen, ob beide laufen:
```bash
sudo systemctl status nexora@<dein-linux-user>.service
sudo systemctl status nexora-internal@<dein-linux-user>.service
```

### Wazuh-Integration

Da beide Services via `systemd`/`journald` loggen (`StandardOutput=journal`),
erscheinen ihre Logs automatisch im Wazuh-Agent, genau wie ihr das heute
schon bei den PAM-Events gesehen habt (`"location": "journald"`) — keine
zusätzliche `ossec.conf`-Änderung nötig, nur abwarten/im Dashboard nach
`nexora-app` bzw. `nexora-internal` filtern (`SyslogIdentifier`).

Guter Folge-Workshop für später, bewusst nicht vorweggenommen: eigene
Wazuh-Regeln schreiben, die z.B. folgende Muster erkennen —
- wiederholte `/reports/download?file=../`-Anfragen (Path-Traversal-Versuch)
- Requests an `/datasource` mit `url=`-Werten, die auf `127.0.0.1` oder
  `localhost` zeigen (SSRF-Versuch)
- `/api/account/update`-Requests, deren JSON-Body ein `"role"`-Feld enthält
  (Mass-Assignment-Versuch)

Das knüpft direkt an den FIM/SCA-Block von heute an, nur diesmal auf
Applikations- statt Betriebssystem-Ebene.

## Die Lücken

Jede Lücke ist im Quellcode mit `--- Lücke N ---` markiert. Die
Beschreibung unten gibt dir die Richtung, ohne die Lösung direkt
vorwegzunehmen — die exakten Schritte stehen jeweils im ausklappbaren
"Lösung"-Block, falls du nicht weiterkommst.

### 1. Geleakter interner API-Key (Recon-Baustein)

Irgendwo im Frontend liegt ein Kommentar, der eigentlich vor dem Deploy
hätte entfernt werden sollen. Schau dir die geladenen JS-Dateien im
Browser (DevTools → Network/Sources) genau an, nicht nur die, die
offensichtlich wichtig aussehen.

<details>
<summary>Lösung</summary>

`static/js/vendor/analytics.bundle.js` enthält als Kommentar:
```js
window.__DEV_INTERNAL_KEY = "nxr_internal_8f2c91a07e4b4d5fa9c0";
```
Dieser Key wird später für Lücke 6 gebraucht.
</details>

### 2. Path Traversal beim Report-Download (`/reports/download`)

Im Account-Bereich gibt's einen Report-Download-Link. Schau dir den
Query-Parameter genau an — wird der Dateiname irgendwie eingeschränkt?

<details>
<summary>Lösung</summary>

```
GET /reports/download?file=../.internal_notes.txt
```
Der Parameter wird naiv mit `os.path.join()` an das Report-Verzeichnis
angehängt, `..`-Sequenzen werden nicht gefiltert. Die ausgebrochene Datei
(`.internal_notes.txt`, eine Ebene über `reports/`) gibt dir einen
expliziten Hinweis auf den nächsten Schritt der Kette (internen Service auf
Port 9090).
</details>

### 3. Mass Assignment in der Account-Update-API (`/api/account/update`)

Das UI zeigt im Account-Bereich nur ein Feld ("Benutzername") an, das sich
ändern lässt. Schau dir im Netzwerk-Tab an, was beim Speichern tatsächlich
als Request rausgeht — und überleg, ob der Server wirklich nur genau dieses
eine Feld akzeptiert, nur weil das UI nur eines anbietet.

<details>
<summary>Lösung</summary>

```bash
curl -b <deine-session-cookie> -H "Content-Type: application/json" \
  -d '{"username":"dein-name","role":"admin","credits":999999}' \
  http://<ziel>:8082/api/account/update
```
Der Server filtert nur nach *existierenden Spalten* (`username`, `role`,
`plan`, `credits`), nicht danach, welche Felder der eingeloggte User selbst
ändern dürfen sollte. Das ist der "einfache" Weg zu Admin-Rechten — die
SSRF-Kette (Lücken 1+6) ist der "anspruchsvollere" Weg zum gleichen Ziel.
</details>

### 4. Stored XSS in Projekt-Kommentaren

Kommentare unter einem Projekt werden ungefiltert gerendert. Was passiert,
wenn dein Kommentar selbst HTML/JS enthält?

<details>
<summary>Lösung</summary>

```
<script>alert(document.cookie)</script>
```
als Kommentartext, abgeschickt und das Projekt neu geladen — das Skript
wird ausgeführt, nicht als Text angezeigt. Betrifft auch jeden anderen, der
sich das Projekt später ansieht (inkl. eines Admins, falls der Mitglied im
Projekt wäre — klassisches Stored-XSS-Risiko für Session-Hijacking in
echten Apps, hier simuliert ohne echte Cookie-Lücke).
</details>

### 5. IDOR bei der Rechnungs-API (`/api/invoices/<id>`)

Im Account-Bereich siehst du einen Link zu deiner eigenen Rechnung mit
einer bestimmten ID. Was, wenn du die ID einfach hoch- oder runterzählst?

<details>
<summary>Lösung</summary>

```
GET /api/invoices/1
GET /api/invoices/2
GET /api/invoices/3
GET /api/invoices/4
```
Keine Prüfung, ob die Rechnung auch wirklich dir gehört — Rechnung #4
gehört dem `admin`-Account und verrät den Jahrespreis der
"vertraulichen" Enterprise-Lizenz.
</details>

### 6. SSRF in der Datenquellen-Vorschau (`/datasource`) — die eigentliche Kette

Die Datenquellen-Seite ruft serverseitig jede URL ab, die du eingibst,
und zeigt dir eine Vorschau. Der Server selbst läuft aber auf derselben
Maschine wie der interne Admin-Service aus Lücke 1/2 — was kann der Server
erreichen, das du von außen (auch von Kali im anderen Subnetz) nicht
erreichen kannst?

<details>
<summary>Lösung (die volle Kette)</summary>

1. Internen Service per SSRF entdecken:
   ```
   POST /datasource   url=http://127.0.0.1:9090/internal/health
   ```
2. Mit dem Key aus Lücke 1 und dem Pfad-Hinweis aus Lücke 2 den
   Promote-Endpunkt per SSRF aufrufen (bewusst als GET gebaut, damit eine
   einfache SSRF-Lücke ihn überhaupt erreichen kann):
   ```
   POST /datasource   url=http://127.0.0.1:9090/internal/admin/promote?key=nxr_internal_8f2c91a07e4b4d5fa9c0&username=<dein-account>
   ```
3. `/admin` neu laden — du bist jetzt Admin, ganz ohne das Passwort des
   echten Admin-Accounts zu kennen, und ganz ohne direkten Zugriff auf den
   internen Service von außen.
</details>

## Angriffsreihenfolge, die sich anbietet

1. Account registrieren, einloggen, Dashboard/Account-Bereich erkunden
2. JS-Dateien im Browser durchsehen → internen Key finden (Lücke 1)
3. Report-Download-Parameter manipulieren → `.internal_notes.txt` lesen,
   Hinweis auf internen Service auf Port 9090 (Lücke 2)
4. Optional als Schnellweg: Mass Assignment direkt zu Admin (Lücke 3)
5. Stored XSS im Kommentarfeld demonstrieren (Lücke 4)
6. IDOR bei den Rechnungen durchprobieren (Lücke 5)
7. Die eigentliche Kette: SSRF nutzen, um den internen Service zu
   erreichen und dich selbst zum Admin zu machen (Lücke 6)

## Fixes (zum Nachlesen, wenn du fertig bist)

- **Path Traversal:** `werkzeug.utils.secure_filename()` oder explizit
  gegen `..`/absolute Pfade prüfen, idealerweise `os.path.realpath()` gegen
  das erlaubte Basisverzeichnis abgleichen.
- **Mass Assignment:** striktes Whitelisting der Felder, die ein
  eingeloggter User selbst ändern darf (niemals `role` darunter).
- **Stored XSS:** nie `|safe` auf Nutzereingaben, Jinja2s Auto-Escaping
  normal greifen lassen.
- **IDOR:** immer zusätzlich `WHERE user_id = ?` prüfen, nicht nur "ist
  jemand eingeloggt".
- **SSRF:** Allowlist für erlaubte Ziel-Hosts, private/Loopback-Adressen
  (`127.0.0.0/8`, `10.0.0.0/8`, `169.254.0.0/16`, …) grundsätzlich blocken,
  idealerweise über ein dediziertes Egress-Proxy statt direktem
  `requests.get()` mit Nutzer-Input.
- **Interner Service:** "nur intern erreichbar" ist keine
  Authentifizierung — ein echter interner Service sollte trotzdem eigene,
  starke Auth haben (hier zumindest vorhanden, aber der Key landet zu
  leicht im Frontend-Bundle).

## Bekannte Grenzen

- Kein HTTPS (Lab-intern, bewusst einfach gehalten)
- Passwort-Hashing bewusst simpel (MD5, kein Salt) — Fokus liegt auf den
  App-Logik-Lücken, nicht auf Passwort-Storage-Best-Practices
