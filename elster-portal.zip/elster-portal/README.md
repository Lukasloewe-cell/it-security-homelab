# Elster IT-Service — absichtlich verwundbares Mitarbeiterportal

Ein selbst geschriebenes Flask-Webapp, die ein internes Support-Ticket-System
einer fiktiven Firma ("Elster Systeme GmbH") simuliert — mit bewusst
eingebauten Sicherheitslücken zum Üben im eigenen Homelab. Gedacht als Ziel
hinter der OPNsense-Firewall, erreichbar nur über den einen freigegebenen
Port von Kali aus (siehe Netzplan im Homelab-Repo).

**Nur für dein eigenes, isoliertes Lab-Netz. Nicht in ein Netz stellen, das
nicht vollständig unter deiner Kontrolle ist.**

## Deployment auf der Ubuntu-VM (192.168.10.20)

```bash
# Projektordner auf die Ubuntu-VM kopieren, dann:
cd elster-portal
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 init_db.py
python3 app.py
```

Die App läuft dann auf Port 8081 (`0.0.0.0:8081`), gemäß deiner bestehenden
OPNsense-Freigabe. Ohne venv geht's auch direkt mit
`pip install --break-system-packages flask`.

Zum Neuaufsetzen der Datenbank (z.B. nach dem Rumspielen) einfach
`python3 init_db.py` erneut ausführen — löscht `portal.db` und legt sie neu an.

## Schwachstellen-Übersicht

Jede Lücke ist auch im Quellcode selbst mit einem Kommentar markiert
(`# --- Lücke N ---`), falls du nachschauen willst, wo genau sie sitzt.

### 1. SQL Injection im Login (`app.py`, Route `/login`)

**Was:** Der Benutzername wird per f-String direkt in die SQL-Query
eingebaut, statt parametrisiert (`?`) übergeben zu werden.

**Exploit:** Im Login-Formular als Benutzername eingeben:
```
admin' --
```
(Passwort-Feld kann beliebig gefüllt sein.) Das `--` kommentiert den Rest
der Query aus (inkl. Passwort-Prüfung) — du bist als `admin` eingeloggt,
ohne das Passwort zu kennen.

Für eine volle Dump-Übung eignet sich auch `sqlmap` gegen den Login-Endpunkt,
oder manuelle UNION-based Payloads, um die `users`-Tabelle (inkl. MD5-Hashes)
auszulesen — die Hashes sind dann wieder mit Hashcat + rockyou.txt crackbar,
genau wie bei deiner DVWA-Übung.

**Fix:** Parametrisierte Query: `db.execute("SELECT ... WHERE username = ? AND password = ?", (username, password_hash))`.

### 2. IDOR beim Ticket-Aufruf (`app.py`, Route `/ticket/<id>`)

**Was:** Die Route prüft nur, ob überhaupt jemand eingeloggt ist — nicht,
ob das Ticket auch dem eingeloggten Nutzer gehört.

**Exploit:** Als normaler Mitarbeiter (z.B. `j.hartmann`) einfach die
Ticket-ID in der URL hochzählen: `/ticket/1`, `/ticket/2`, `/ticket/6` …
Ticket #6 ist eine interne Admin-Notiz, die eigentlich nicht für
Mitarbeiter sichtbar sein soll.

**Fix:** Zusätzlich `WHERE t.id = ? AND t.user_id = ?` prüfen (oder bei
Admin-Rolle eine explizite Ausnahme).

### 3. Reflected XSS in der Suche (`app.py`, Route `/search`)

**Was:** Der Suchbegriff wird per Python-String-Concatenation direkt ins
HTML eingebettet und dann mit `|safe` ungeescaped ausgegeben — der normale,
auto-escapende Jinja-Mechanismus wird hier bewusst umgangen.

**Exploit:** In der Suche eingeben:
```
<script>alert(document.cookie)</script>
```
Statt als Text angezeigt zu werden, wird das Skript ausgeführt.

**Fix:** Nutzereingaben nie mit `|safe` ausgeben; den Suchbegriff normal
über `{{ q }}` rendern lassen (auto-escaped).

### 4. Server-Side Template Injection / SSTI (`app.py`, Route `/profile`)

**Was:** Die "Über mich"-Bio wird direkt per `render_template_string(bio)`
gerendert — der Nutzer-Input wird also als Jinja2-**Template** interpretiert,
nicht als reiner Text.

**Exploit:** Im Bio-Feld eintragen und speichern:
```
{{ 7*7 }}
```
Die Vorschau zeigt `49` statt des Textes — Beweis, dass Code ausgeführt
wird. Nächster Schritt zum Daten-Leak:
```
{{ config }}
```
zeigt die komplette Flask-Konfiguration inkl. `SECRET_KEY` im Klartext.
Für vollen RCE gibt's öffentlich dokumentierte Jinja2-SSTI-Gadget-Chains
(Stichwort "Jinja2 SSTI RCE payload", z.B. über
`{{ ''.__class__.__mro__[1].__subclasses__() }}` und von dort zu
`subprocess.Popen`) — gutes nächstes Lernthema, wenn du tiefer einsteigen willst.

**Fix:** Nutzereingaben nie an `render_template_string()` übergeben; Bio
ganz normal als Variable in ein bestehendes Template einsetzen (`{{ bio }}`).

### 5. Geleakter SECRET_KEY über Backup-Datei (`static/config.py.bak`)

**Was:** Eine "vergessene" Backup-Datei liegt im Webroot und ist direkt
unter `/static/config.py.bak` abrufbar. Sie enthält den Flask-`SECRET_KEY`,
mit dem Session-Cookies signiert werden.

**Exploit:**
```bash
curl http://192.168.10.20:8081/static/config.py.bak
```
Mit dem geleakten Key lässt sich per [`flask-unsign`](https://pypi.org/project/flask-unsign/)
ein beliebiges, gültig signiertes Session-Cookie selbst bauen — z.B. mit
`role=admin`, ganz ohne echten Login:
```bash
pip install flask-unsign --break-system-packages
flask-unsign --sign --cookie "{'logged_in': True, 'user_id': 1, 'username': 'admin', 'role': 'admin', 'full_name': 'Admin'}" --secret 'ElsterPortal_2024_SuperSecret!'
```
Das Ergebnis als Cookie `session=<wert>` im Browser setzen (z.B. über die
Dev-Tools) — damit bist du als Admin eingeloggt, auch ohne das echte
Passwort zu kennen.

**Fix:** Keine Backup-/Config-Dateien im Webroot vergessen; `SECRET_KEY`
aus einer Umgebungsvariable statt hartcodiert im Quellcode.

### 6. Versteckter Admin-Bereich (`app.py`, Route `/portal-mgmt-77x`)

**Was:** Der Admin-Bereich ist nur durch einen "geheimen" Pfad geschützt
(security through obscurity), nicht durch echte Autorisierung außer der
Session-Rollenprüfung — und der Pfad ist an zwei Stellen verraten:
in `robots.txt` (`Disallow: /portal-mgmt-77x`) und als HTML-Kommentar im
Footer jeder Seite (`<!-- TODO: ... Zwischenloesung ueber /portal-mgmt-77x -->`).

**Exploit:** `curl http://192.168.10.20:8081/robots.txt` oder einfach den
Seitenquelltext ansehen — der Pfad steht direkt drin. Mit einem
gefälschten Admin-Cookie (siehe Lücke 5) oder der SQLi-Bypass-Methode
(Lücke 1, da `admin' --` dich mit `role=admin` einloggt) ist der Bereich
dann voll erreichbar.

**Fix:** Admin-Bereiche nie nur über einen unauffindbaren Pfad "schützen" —
echte Rollenprüfung in Kombination mit robuster Session-/Secret-Verwaltung
(siehe Lücke 5) nötig.

## Angriffsreihenfolge, die sich anbietet

1. `robots.txt` abrufen → verrät beide "geheimen" Pfade
2. `static/config.py.bak` abrufen → `SECRET_KEY` geleakt
3. Login-Bypass per SQLi (`admin' --`) → direkt als Admin drin, ODER
   gefälschtes Cookie per `flask-unsign` mit dem geleakten Key
4. Mit normalem Nutzer-Account: IDOR auf Tickets durchprobieren
5. XSS in der Suche demonstrieren
6. SSTI im Profil bis zum `{{ config }}`-Leak (und optional weiter zur
   RCE-Gadget-Chain)

## Bekannte Grenzen

- Kein HTTPS (Lab-intern, bewusst einfach gehalten)
- `debug=False` ist gesetzt, damit der Flask-Debugger (der selbst eine
  RCE-Lücke wäre, wenn er aktiv bleibt) nicht zusätzlich offen ist — die
  SSTI-Lücke reicht als Lernbeispiel
