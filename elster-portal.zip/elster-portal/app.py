#!/usr/bin/env python3
"""
Elster IT-Service -- internes Mitarbeiterportal (Support-Ticket-System)

ACHTUNG: Diese Anwendung enthaelt ABSICHTLICH eingebaute Sicherheitsluecken.
Sie ist ausschliesslich zum Trainieren von Angriffstechniken im eigenen,
isolierten Homelab gedacht (siehe README.md fuer die vollstaendige
Schwachstellen-Liste inkl. Exploit-Wegen und Fixes). NICHT fuer den
produktiven Einsatz oder ein Netz, das nicht vollstaendig unter eigener
Kontrolle steht.

Bewusst eingebaute Luecken (Details + Exploit-Schritte in README.md):
  1. SQL Injection im Login (Username wird ungesanitisiert in die Query
     eingebaut)
  2. IDOR beim Ticket-Aufruf (/ticket/<id> prueft nur "eingeloggt?",
     nicht "gehoert das Ticket diesem Nutzer?")
  3. Reflected XSS in der Suche (Suchbegriff wird ungeescaped ins HTML
     zurueckgespiegelt)
  4. Server-Side Template Injection (SSTI) in der Profil-Vorschau
     (Nutzer-Bio wird direkt als Jinja2-Template gerendert)
  5. Hartcodierter SECRET_KEY + Backup-Datei im Webroot (static/config.py.bak)
     -> bei Leck faelschbare Session-Cookies (siehe flask-unsign)
  6. Versteckter Admin-Pfad, nur durch robots.txt/HTML-Kommentar "geschuetzt"
     (security through obscurity statt echter Autorisierung)
"""

import hashlib
import sqlite3
from pathlib import Path

from flask import (
    Flask, request, session, redirect, url_for,
    render_template, render_template_string, g,
)

DB_PATH = Path(__file__).parent / "portal.db"

app = Flask(__name__)

# --- Luecke 5: hartcodierter, schwacher Secret Key -----------------------
# Dieser Key signiert die Session-Cookies (Flask/itsdangerous). Er ist
# zusaetzlich (absichtlich) in static/config.py.bak als "vergessenes
# Backup" im Webroot abgelegt. Wer ihn findet, kann mit einem Tool wie
# flask-unsign eigene, gueltige Session-Cookies faelschen -- z.B. mit
# role=admin, ganz ohne Passwort.
app.config["SECRET_KEY"] = "ElsterPortal_2024_SuperSecret!"


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def login_required(view):
    from functools import wraps

    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

@app.route("/", methods=["GET"])
def index():
    if session.get("logged_in"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        password_hash = hashlib.md5(password.encode()).hexdigest()

        # --- Luecke 1: SQL Injection -------------------------------------
        # Der Username wird direkt per f-String in die Query eingebaut,
        # statt einen parametrisierten Query (?, ?) zu nutzen. Ein
        # Username wie   admin' --   kommentiert die Passwort-Pruefung
        # komplett aus und loggt als 'admin' ein, ganz ohne Passwort zu
        # kennen. Mit UNION-based Payloads laesst sich die gesamte
        # users-Tabelle ueber dieses Feld exfiltrieren.
        db = get_db()
        query = (
            f"SELECT id, username, role, full_name FROM users "
            f"WHERE username = '{username}' AND password = '{password_hash}'"
        )
        try:
            row = db.execute(query).fetchone()
        except sqlite3.Error as e:
            # Fehlermeldung bewusst nicht versteckt -- ermoeglicht
            # Error-Based SQLi zum Ausprobieren von Payloads.
            error = f"Datenbankfehler: {e}"
            row = None

        if row:
            session["logged_in"] = True
            session["user_id"] = row["id"]
            session["username"] = row["username"]
            session["role"] = row["role"]
            session["full_name"] = row["full_name"]
            return redirect(url_for("dashboard"))
        elif error is None:
            error = "Benutzername oder Passwort falsch."

    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Dashboard / Tickets
# ---------------------------------------------------------------------------

@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    tickets = db.execute(
        "SELECT * FROM tickets WHERE user_id = ? ORDER BY id DESC",
        (session["user_id"],),
    ).fetchall()
    return render_template("dashboard.html", tickets=tickets)


@app.route("/ticket/<int:ticket_id>")
@login_required
def ticket_detail(ticket_id):
    # --- Luecke 2: IDOR -------------------------------------------------
    # Es wird nur geprueft, ob ueberhaupt jemand eingeloggt ist -- NICHT,
    # ob das Ticket mit dieser ID auch dem eingeloggten Nutzer gehoert.
    # Einfach die ID in der URL hochzaehlen (/ticket/1, /ticket/2, ...)
    # zeigt fremde Tickets, inkl. der internen Notiz von 'admin'.
    db = get_db()
    ticket = db.execute(
        "SELECT t.*, u.username AS owner FROM tickets t "
        "JOIN users u ON u.id = t.user_id WHERE t.id = ?",
        (ticket_id,),
    ).fetchone()
    if ticket is None:
        return render_template("ticket.html", ticket=None), 404
    return render_template("ticket.html", ticket=ticket)


# ---------------------------------------------------------------------------
# Suche (XSS)
# ---------------------------------------------------------------------------

@app.route("/search")
@login_required
def search():
    q = request.args.get("q", "")
    results = []
    if q:
        db = get_db()
        # Hinweis: die DB-Abfrage selbst ist hier parametrisiert (kein
        # SQLi an dieser Stelle) -- die Luecke liegt in der Ausgabe, s.u.
        results = db.execute(
            "SELECT t.*, u.username AS owner FROM tickets t "
            "JOIN users u ON u.id = t.user_id "
            "WHERE t.subject LIKE ? OR t.body LIKE ?",
            (f"%{q}%", f"%{q}%"),
        ).fetchall()

    # --- Luecke 3: Reflected XSS -----------------------------------------
    # Der Suchbegriff wird per render_template_string + manuellem
    # String-Zusammenbau ungeescaped in die Seite eingebettet (statt ihn
    # ueber den normalen, auto-escapenden Jinja-Mechanismus in
    # search.html auszugeben). Ein Suchbegriff wie
    #   <script>alert(document.cookie)</script>
    # wird deshalb direkt im Browser ausgefuehrt statt als Text angezeigt.
    echo_html = f"<p class='search-echo'>Suche nach: {q}</p>" if q else ""

    return render_template_string(
        SEARCH_TEMPLATE, echo_html=echo_html, results=results, q=q
    )


# Eigenes Template fuer /search, weil der verwundbare echo_html-Teil
# direkt als Template-String gerendert wird (siehe render_template_string
# oben) -- der Rest der Seite kommt aus templates/search_shell.html.
with open(Path(__file__).parent / "templates" / "search_shell.html") as _f:
    SEARCH_TEMPLATE = _f.read()


# ---------------------------------------------------------------------------
# Profil (SSTI)
# ---------------------------------------------------------------------------

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    db = get_db()
    preview = None
    if request.method == "POST":
        bio = request.form.get("bio", "")
        db.execute(
            "UPDATE users SET bio = ? WHERE id = ?",
            (bio, session["user_id"]),
        )
        db.commit()

        # --- Luecke 4: Server-Side Template Injection (SSTI) -------------
        # Die vom Nutzer eingegebene Bio wird direkt als Jinja2-Template
        # interpretiert, nicht als reiner Text. Payloads wie
        #   {{ 7*7 }}                              -> rendert "49"
        #   {{ config }}                           -> leakt Flask-Config (inkl. SECRET_KEY!)
        #   {{ ''.__class__.__mro__[1].__subclasses__() }}  -> Einstieg in RCE-Gadget-Chain
        # werden ausgefuehrt statt angezeigt.
        try:
            preview = render_template_string(bio)
        except Exception as e:
            preview = f"[Fehler beim Rendern: {e}]"

    user = db.execute(
        "SELECT * FROM users WHERE id = ?", (session["user_id"],)
    ).fetchone()
    return render_template("profile.html", user=user, preview=preview)


# ---------------------------------------------------------------------------
# Luecke 6: versteckter Admin-Bereich (nur "security through obscurity")
# ---------------------------------------------------------------------------

@app.route("/portal-mgmt-77x")
def hidden_admin():
    # Es wird NUR session["role"] geprueft -- ein Wert, der clientseitig
    # im signierten Cookie steht. Mit dem geleakten SECRET_KEY (siehe
    # static/config.py.bak) kann ein Angreifer sich per flask-unsign ein
    # Cookie mit role='admin' selbst bauen, ganz ohne echten Admin-Login.
    if session.get("role") != "admin":
        return "Zugriff verweigert.", 403
    db = get_db()
    users = db.execute("SELECT id, username, role, full_name FROM users").fetchall()
    return render_template("admin.html", users=users)


@app.route("/robots.txt")
def robots():
    # Verweist absichtlich auf den "versteckten" Admin-Pfad -- klassischer
    # Recon-Fehler: robots.txt soll Suchmaschinen aussperren, verraet
    # einem Angreifer aber genau, wo er nachsehen soll.
    return (
        "User-agent: *\n"
        "Disallow: /portal-mgmt-77x\n"
        "Disallow: /static/config.py.bak\n",
        200,
        {"Content-Type": "text/plain"},
    )


if __name__ == "__main__":
    if not DB_PATH.exists():
        print("[!] Keine Datenbank gefunden -- bitte zuerst 'python3 init_db.py' ausfuehren.")
    app.run(host="0.0.0.0", port=8081, debug=False)
