#!/usr/bin/env python3
"""
init_db.py -- legt die SQLite-Datenbank fuer das Elster-Portal an und
befuellt sie mit Testdaten (Mitarbeiter + Tickets).

Die Passwort-Hashes sind bewusst MD5 (schwach, ungesalzen) -- genau wie
bei klassischen Lecks real existierender Systeme, und damit per
Hashcat + rockyou.txt crackbar (gleiche Technik, die du schon bei der
DVWA-SQLi genutzt hast).
"""

import hashlib
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "portal.db"


def md5(s: str) -> str:
    return hashlib.md5(s.encode()).hexdigest()


USERS = [
    # (username, password_klartext, role, full_name)
    ("admin", "DragonFire99", "admin", "System Administrator"),
    ("j.hartmann", "sommer2024", "employee", "Julia Hartmann"),
    ("m.weber", "passwort123", "employee", "Markus Weber"),
    ("s.koenig", "qwertz2023", "employee", "Sabine König"),
]

TICKETS = [
    # (username_owner, subject, body, status)
    ("j.hartmann", "VPN-Verbindung bricht ständig ab",
     "Seit dem letzten Update bricht die VPN-Verbindung alle 10 Minuten ab. Betrifft nur mein Notebook.",
     "offen"),
    ("j.hartmann", "Zugriff auf Projektlaufwerk fehlt",
     "Ich habe keinen Zugriff mehr auf \\\\fileserver\\projekte\\nordwind. Vorher ging es.",
     "in Bearbeitung"),
    ("m.weber", "Monitor flackert",
     "Der rechte von meinen zwei Monitoren flackert seit heute morgen.",
     "offen"),
    ("m.weber", "Passwort-Reset für Mailkonto",
     "Bitte mein Postfach-Passwort zurücksetzen, ich hab mich ausgesperrt.",
     "geschlossen"),
    ("s.koenig", "Drucker im 2. OG druckt nicht",
     "Der Drucker zeigt 'Papierstau', ist aber keiner drin. Dringend, brauche Ausdrucke für 14 Uhr.",
     "offen"),
    ("admin", "Interne Notiz: Lizenzserver-Migration",
     "Migration des Lizenzservers auf neue Hardware für Q1 geplant. Nicht fuer Mitarbeiter sichtbar machen.",
     "in Bearbeitung"),
]


def main():
    if DB_PATH.exists():
        DB_PATH.unlink()

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'employee',
            full_name TEXT NOT NULL,
            bio TEXT NOT NULL DEFAULT ''
        )
    """)

    cur.execute("""
        CREATE TABLE tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            subject TEXT NOT NULL,
            body TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'offen',
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)

    user_ids = {}
    for username, password, role, full_name in USERS:
        cur.execute(
            "INSERT INTO users (username, password, role, full_name) VALUES (?, ?, ?, ?)",
            (username, md5(password), role, full_name),
        )
        user_ids[username] = cur.lastrowid

    for owner, subject, body, status in TICKETS:
        cur.execute(
            "INSERT INTO tickets (user_id, subject, body, status) VALUES (?, ?, ?, ?)",
            (user_ids[owner], subject, body, status),
        )

    conn.commit()
    conn.close()
    print(f"[*] Datenbank angelegt: {DB_PATH}")
    print(f"[*] {len(USERS)} Nutzer, {len(TICKETS)} Tickets angelegt.")
    print("[*] Testlogin (fuer normalen, nicht-exploitierten Zugang): j.hartmann / sommer2024")


if __name__ == "__main__":
    main()
