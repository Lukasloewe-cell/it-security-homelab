"""
graph_builder.py — baut aus den Scan-Ergebnissen einen Graphen fuer die
Visualisierung.

Wichtiger konzeptioneller Unterschied zu BloodHound:
BloodHound kennt echte Berechtigungs-Kanten (A kann B administrieren,
weil AD das so speichert). Ein reiner nmap-Scan im Heimnetz hat sowas
nicht -- wir sehen nur, welche Geraete da sind und welche Ports offen
sind, nicht wer mit wem tatsaechlich kommuniziert oder wer wen
kontrollieren kann (das wuerde echten Netzwerk-Traffic/NetFlow-Daten
brauchen, nicht nur einen Portscan).

Deshalb baut dieses Modul bewusst eine ehrlichere Darstellung:
- Jedes Subnetz wird ein Hub-Node (zeigt Netzwerksegmentierung --
  z.B. ob dein Kali im selben Netz haengt wie der Windows Server,
  oder ob VLANs sauber trennen)
- Jedes Geraet verbindet sich mit seinem Subnetz-Hub
- Jedes Geraet bekommt eine Risiko-Einstufung basierend auf offenen
  Ports (eine simple Heuristik, KEIN echter Vulnerability-Scan --
  das wird im Code und im Tooltip auch so benannt, um nichts
  vorzutaeuschen)
"""

import json
import ipaddress
from dataclasses import dataclass, field


# Ports, die typischerweise auf ein erhoehtes Risiko hindeuten, wenn sie
# von aussen/aus einem anderen Netzsegment erreichbar sind. Das ist eine
# grobe, manuell kuratierte Liste -- kein Ersatz fuer einen echten
# Vulnerability-Scanner wie Nessus/OpenVAS, aber gut genug fuer eine
# erste visuelle Einordnung im eigenen Lab.
HIGH_RISK_PORTS = {
    21: "FTP (oft Klartext-Login)",
    23: "Telnet (unverschluesselt)",
    445: "SMB (Lateral-Movement-Ziel)",
    3389: "RDP (Brute-Force-Ziel, falls exponiert)",
    5900: "VNC (oft ohne/mit schwachem Passwort)",
}
MEDIUM_RISK_PORTS = {
    22: "SSH (Brute-Force-Ziel bei schwachem Passwort)",
    80: "HTTP (unverschluesselt)",
    3306: "MySQL (sollte selten direkt exponiert sein)",
    5432: "PostgreSQL (sollte selten direkt exponiert sein)",
}


def assess_risk(services: list[dict]) -> tuple[str, list[str]]:
    """
    Simple Heuristik: schaut nur auf die PORT-NUMMER, nicht auf
    tatsaechliche Schwachstellen (kein CVE-Abgleich, keine Versions-
    pruefung). Gibt ein Risiko-Level ("high"/"medium"/"low") und eine
    Liste von Begruendungen zurueck, die im Tooltip angezeigt werden.
    """
    reasons = []
    level = "low"

    for svc in services:
        port = svc["port"]
        if port in HIGH_RISK_PORTS:
            reasons.append(f"Port {port}: {HIGH_RISK_PORTS[port]}")
            level = "high"
        elif port in MEDIUM_RISK_PORTS and level != "high":
            reasons.append(f"Port {port}: {MEDIUM_RISK_PORTS[port]}")
            level = "medium"

    return level, reasons


def subnet_id(ip: str) -> str:
    """Gibt das /24-Subnetz einer IP als String zurueck, z.B. '192.168.10.0/24'."""
    network = ipaddress.ip_network(f"{ip}/24", strict=False)
    return str(network)


def build_graph(devices: list[dict]) -> dict:
    """
    Nimmt die Liste der gescannten Geraete (als Dicts, z.B. aus
    scan_result.json) und baut eine Graph-Struktur im Format
    {"nodes": [...], "edges": [...]}, die vis.js direkt einlesen kann.
    """
    nodes = []
    edges = []
    seen_subnets = set()

    for device in devices:
        ip = device["ip"]
        label = device.get("hostname") or ip
        services = device.get("services", [])
        risk_level, risk_reasons = assess_risk(services)

        # Geraete-Node
        nodes.append({
            "id": ip,
            "label": label,
            "group": risk_level,  # vis.js faerbt Nodes nach "group" ein
            "title": _build_tooltip(device, risk_reasons),  # Hover-Text
        })

        # Subnetz-Hub, falls noch nicht angelegt
        subnet = subnet_id(ip)
        if subnet not in seen_subnets:
            nodes.append({
                "id": subnet,
                "label": subnet,
                "group": "subnet",
            })
            seen_subnets.add(subnet)

        # Kante Geraet -> sein Subnetz
        edges.append({"from": ip, "to": subnet})

    return {"nodes": nodes, "edges": edges}


def _build_tooltip(device: dict, risk_reasons: list[str]) -> str:
    lines = [f"IP: {device['ip']}"]
    if device.get("hostname"):
        lines.append(f"Hostname: {device['hostname']}")
    if device.get("vendor"):
        lines.append(f"Hersteller: {device['vendor']}")

    services = device.get("services", [])
    if services:
        lines.append("Offene Ports:")
        for svc in services:
            info = f"  {svc['port']}/{svc['protocol']} - {svc['name']}"
            if svc.get("product"):
                info += f" ({svc['product']} {svc.get('version', '')})".rstrip()
            lines.append(info)
    else:
        lines.append("Keine offenen Ports gefunden")

    if risk_reasons:
        lines.append("Risiko-Hinweise (Heuristik, kein Vuln-Scan):")
        for r in risk_reasons:
            lines.append(f"  - {r}")

    return "\n".join(lines)


if __name__ == "__main__":
    with open("../data/scan_result.json") as f:
        devices = json.load(f)

    graph = build_graph(devices)

    with open("../data/graph.json", "w") as f:
        json.dump(graph, f, indent=2)

    print(f"[*] Graph gebaut: {len(graph['nodes'])} Nodes, {len(graph['edges'])} Edges")
    print("[*] Gespeichert unter ../data/graph.json")
