"""
scan.py — Netzwerk-Discovery und Port-/Service-Scan fuers Homelab.

Idee: nmap macht die eigentliche Netzwerkarbeit (das neu zu erfinden waere
sinnlos und fehleranfaellig). Dieses Modul ruft nmap als Subprozess auf,
laesst es Ergebnisse im XML-Format ausgeben (nmap -oX -) und wandelt das
XML in einfache Python-Datenstrukturen (Listen von Dicts) um, die das
restliche Tool weiterverarbeiten kann.

Warum XML statt dem normalen Text-Output? nmaps Text-Output ist für
Menschen gedacht und aendert sich je nach Version/Optionen leicht im
Format -- das macht zuverlaessiges Parsen schwer. Das XML-Format ist
stabil strukturiert und genau dafuer gedacht, von anderen Programmen
gelesen zu werden.
"""

import subprocess
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field


@dataclass
class Service:
    """Ein einzelner offener Port mit dem, was nmap darueber herausgefunden hat."""
    port: int
    protocol: str       # "tcp" oder "udp"
    name: str           # z.B. "http", "microsoft-ds"
    product: str = ""   # z.B. "Apache httpd" (falls nmap es per -sV erkennt)
    version: str = ""   # z.B. "2.4.54"


@dataclass
class Device:
    """Ein gefundenes Geraet im Netzwerk."""
    ip: str
    hostname: str = ""
    mac: str = ""
    vendor: str = ""              # z.B. "Raspberry Pi Foundation", aus MAC-Vendor-DB
    os_guess: str = ""
    services: list[Service] = field(default_factory=list)


def run_nmap(target: str, fast: bool = True) -> str:
    """
    Fuehrt nmap gegen das Zielnetz/die Ziel-IP aus und gibt den rohen
    XML-Output als String zurueck.

    target: z.B. "192.168.10.0/24" oder eine einzelne IP
    fast:   True = schneller Scan (Top-1000-Ports, -T4), gut für eine erste
            Uebersicht. False = vollstaendiger Portscan (-p-), dauert
            deutlich laenger, aber findet auch Dienste auf ungewoehnlichen
            Ports.

    Wichtig: Wir scannen hier nur mit -sV (Service-/Versionserkennung),
    kein -O (OS-Detection) und keine aggressiven NSE-Scripts -- das haelt
    den Scan schnell und unauffaellig genug fuer ein Heimnetz-Tool, das
    man auch oefter mal laufen lassen will.
    """
    cmd = ["nmap", "-sV", "-oX", "-"]
    if fast:
        cmd += ["-T4"]
    else:
        cmd += ["-p-", "-T4"]
    cmd.append(target)

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    if result.returncode != 0:
        raise RuntimeError(f"nmap ist fehlgeschlagen: {result.stderr}")
    return result.stdout


def parse_nmap_xml(xml_text: str) -> list[Device]:
    """
    Wandelt nmaps XML-Output in eine Liste von Device-Objekten um.

    Die nmap-XML-Struktur (vereinfacht):
    <nmaprun>
      <host>
        <status state="up"/>
        <address addr="192.168.10.40" addrtype="ipv4"/>
        <address addr="AA:BB:CC:.." addrtype="mac" vendor="..."/>
        <hostnames><hostname name="dc01.lab.local"/></hostnames>
        <ports>
          <port protocol="tcp" portid="445">
            <state state="open"/>
            <service name="microsoft-ds" product="..." version="..."/>
          </port>
          ...
        </ports>
      </host>
      ...
    </nmaprun>
    """
    root = ET.fromstring(xml_text)
    devices = []

    for host in root.findall("host"):
        status = host.find("status")
        if status is None or status.get("state") != "up":
            continue  # Geraet war offline/nicht erreichbar, ueberspringen

        device = Device(ip="")
        for addr in host.findall("address"):
            addrtype = addr.get("addrtype")
            if addrtype == "ipv4":
                device.ip = addr.get("addr", "")
            elif addrtype == "mac":
                device.mac = addr.get("addr", "")
                device.vendor = addr.get("vendor", "")

        hostnames = host.find("hostnames")
        if hostnames is not None:
            hostname_el = hostnames.find("hostname")
            if hostname_el is not None:
                device.hostname = hostname_el.get("name", "")

        ports_el = host.find("ports")
        if ports_el is not None:
            for port_el in ports_el.findall("port"):
                state = port_el.find("state")
                if state is None or state.get("state") != "open":
                    continue  # nur offene Ports interessieren uns

                service_el = port_el.find("service")
                service = Service(
                    port=int(port_el.get("portid", 0)),
                    protocol=port_el.get("protocol", "tcp"),
                    name=service_el.get("name", "unknown") if service_el is not None else "unknown",
                    product=service_el.get("product", "") if service_el is not None else "",
                    version=service_el.get("version", "") if service_el is not None else "",
                )
                device.services.append(service)

        if device.ip:  # nur Geraete mit erkannter IP uebernehmen
            devices.append(device)

    return devices


def scan_network(target: str, fast: bool = True) -> list[Device]:
    """Komfort-Funktion: scannt und parst in einem Schritt."""
    xml_output = run_nmap(target, fast=fast)
    return parse_nmap_xml(xml_output)


if __name__ == "__main__":
    import sys
    import json
    from dataclasses import asdict

    if len(sys.argv) < 2:
        print("Nutzung: python3 scan.py <ziel-netz, z.B. 192.168.10.0/24> [--full]")
        sys.exit(1)

    target = sys.argv[1]
    fast = "--full" not in sys.argv

    print(f"[*] Scanne {target} ({'schnell' if fast else 'vollstaendig'})...")
    devices = scan_network(target, fast=fast)
    print(f"[*] {len(devices)} aktive Geraete gefunden.")

    # Als JSON speichern, damit das naechste Modul (Graph-Aufbau) es lesen kann
    out_path = "../data/scan_result.json"
    with open(out_path, "w") as f:
        json.dump([asdict(d) for d in devices], f, indent=2)
    print(f"[*] Ergebnis gespeichert unter {out_path}")
