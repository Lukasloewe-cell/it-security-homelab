"""
main.py -- FastAPI-Backend, das den Neo4j-Graphen als JSON fuers Frontend
ausliefert (Cytoscape.js-kompatibles Format: {"nodes": [...], "edges": [...]}).

Warum ueberhaupt eine eigene API statt dem Frontend direkt Cypher-Queries
schicken zu lassen? Zwei Gruende: (1) Neo4j-Zugangsdaten sollen nicht im
Browser landen, (2) das Frontend soll nur "gib mir den Graphen der letzten
X Stunden" sagen muessen, nicht selbst Cypher koennen -- die Query-Logik
gehoert ins Backend.

Start:
  cd homenet-mapper
  uvicorn api.main:app --reload --port 8000
"""

import sys
from pathlib import Path

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware

sys.path.insert(0, str(Path(__file__).parent.parent / "graphdb"))
from connection import get_driver  # noqa: E402

app = FastAPI(title="Homenet Graph API")

# CORS offen fuer lokale Entwicklung (Frontend laeuft auf anderem Port) --
# in einer echten Deployment-Situation wuerde man das auf die konkrete
# Frontend-Origin einschraenken.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/graph")
def get_graph(hours: int = Query(24, description="Nur Alerts der letzten N Stunden beruecksichtigen")):
    """Liefert den kompletten sichtbaren Graphen: alle Hosts, alle Alerts
    der letzten 'hours' Stunden, alle externen IPs, die darin vorkommen --
    plus die Kanten dazwischen."""
    driver = get_driver()
    nodes = {}
    edges = []

    with driver.session() as session:
        # Hosts + ihre Alerts (im Zeitfenster) + die externen IPs daraus
        result = session.run(
            """
            MATCH (h:Host)
            OPTIONAL MATCH (h)-[:TRIGGERED]->(a:Alert)
              WHERE a.timestamp >= datetime() - duration({hours: $hours})
            OPTIONAL MATCH (a)-[:INVOLVES]->(e:ExternalIP)
            RETURN h, a, e
            """,
            hours=hours,
        )
        for record in result:
            h = record["h"]
            a = record["a"]
            e = record["e"]

            host_id = f"host:{h['ip']}"
            if host_id not in nodes:
                nodes[host_id] = {
                    "data": {
                        "id": host_id,
                        "label": h.get("hostname") or h["ip"],
                        "kind": "host",
                        "ip": h["ip"],
                        "open_ports": h.get("open_ports", []),
                    }
                }

            if a is not None:
                alert_id = f"alert:{a['id']}"
                if alert_id not in nodes:
                    nodes[alert_id] = {
                        "data": {
                            "id": alert_id,
                            "label": a.get("description", "Alert"),
                            "kind": "alert",
                            "severity": a.get("severity"),
                            "timestamp": a.get("timestamp"),
                        }
                    }
                edges.append({
                    "data": {
                        "id": f"{host_id}->{alert_id}",
                        "source": host_id,
                        "target": alert_id,
                        "kind": "triggered",
                    }
                })

                if e is not None:
                    ext_id = f"ext:{e['ip']}"
                    if ext_id not in nodes:
                        nodes[ext_id] = {
                            "data": {
                                "id": ext_id,
                                "label": e["ip"],
                                "kind": "external_ip",
                                "reputation": e.get("reputation"),
                            }
                        }
                    edges.append({
                        "data": {
                            "id": f"{alert_id}->{ext_id}",
                            "source": alert_id,
                            "target": ext_id,
                            "kind": "involves",
                        }
                    })

    driver.close()
    return {"nodes": list(nodes.values()), "edges": edges}


@app.get("/health")
def health():
    return {"status": "ok"}
