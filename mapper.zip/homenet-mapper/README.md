# Homenet Mapper

Ein selbst gebautes Python-Tool zur visuellen Kartierung des eigenen Homelab-Netzwerks — grob inspiriert von Maltego/BloodHound, aber bewusst einfacher gehalten und für ein Heimnetz statt Active Directory gedacht.

## Was es macht

1. Scannt ein Netzwerk (oder mehrere Subnetze/VLANs) mit `nmap` und erkennt aktive Geräte, offene Ports und laufende Dienste.
2. Baut daraus einen Graphen: Geräte als Nodes, Subnetze als Hub-Nodes (zeigt Netzwerksegmentierung — z.B. ob VLANs sauber getrennt sind).
3. Stuft jedes Gerät grob nach Risiko ein (heuristisch anhand bekannter "riskanter" Ports wie Telnet, RDP, SMB — **kein** echter Vulnerability-Scan).
4. Zeigt das Ergebnis als interaktiven Graphen im Browser (vis.js), mit Hover-Tooltips pro Gerät.

## Wichtiger konzeptioneller Unterschied zu BloodHound

BloodHound kennt echte Berechtigungsbeziehungen aus Active Directory (wer kann wen administrieren). Ein reiner `nmap`-Scan im Heimnetz hat das nicht — wir sehen nur, welche Geräte da sind, nicht wer tatsächlich mit wem spricht oder wer wen kontrollieren könnte (das bräuchte echten Netzwerk-Traffic, nicht nur einen Portscan). Die Visualisierung zeigt deshalb bewusst **Topologie + Risiko-Einstufung**, keine erfundenen Angriffspfade.

## Architektur

```
homenet-mapper/
├── scanner/
│   ├── scan.py           # nmap-Aufruf + XML-Parsing -> Device/Service-Objekte
│   └── graph_builder.py  # Device-Liste -> Graph-JSON (Nodes + Edges, Risiko-Heuristik)
├── visualizer/
│   └── index.html        # vis.js-basierte interaktive Darstellung
├── data/                 # scan_result.json, graph.json (werden beim Scan erzeugt)
└── run.py                # CLI-Einstiegspunkt, verbindet alle drei Teile
```

## Voraussetzungen

- Python 3.10+ (nutzt `dataclasses` mit `list[...]`-Syntax)
- `nmap` installiert (`sudo apt install nmap` auf Kali meist schon vorhanden)
- Ein moderner Browser

Keine zusätzlichen Python-Pakete nötig — bewusst nur Standardbibliothek (`subprocess`, `xml.etree.ElementTree`, `json`, `ipaddress`) verwendet, um die Abhängigkeiten minimal zu halten.

## Nutzung

```bash
# ins Projektverzeichnis wechseln (z.B. nach dem Entpacken in ~/Downloads)
cd /home/kali/Downloads/homenet-mapper

# Schneller Scan (Top-1000-Ports) + direkt Visualisierung starten
python3 run.py 192.168.10.0/24 --serve

# Vollständiger Portscan (dauert länger, findet auch ungewöhnliche Ports)
python3 run.py 192.168.10.0/24 --full --serve

# Ping-Sweep überspringen (wichtig für Windows-Hosts, die ICMP-Echo per
# Firewall standardmäßig blocken und sonst im Scan fälschlich als "offline"
# übersprungen werden)
python3 run.py 192.168.10.0/24 --no-ping --serve

# Nur scannen, später manuell anschauen
python3 run.py 192.168.10.0/24
python3 -m http.server 8765        # WICHTIG: im Projekt-Root starten, nicht in visualizer/
# dann im Browser: http://localhost:8765/visualizer/
```

**Wichtig:** Immer per `cd` in den tatsächlichen Projektordner wechseln, bevor `run.py` gestartet wird (z.B. `/home/kali/Downloads/homenet-mapper`) — nicht per Doppelklick aus einem Dateimanager heraus öffnen. Manche Dateimanager/Archiv-Vorschauen entpacken Zip-Dateien sonst in einen temporären, teils schreibgeschützten Sandbox-Ordner (z.B. unter `~/.local/share/...`) statt an den Ort, an dem du sie wirklich haben willst — dann kann `data/scan_result.json` nicht gespeichert werden.

**Wichtig:** Der Webserver muss im Projekt-Root (`homenet-mapper/`) gestartet werden, nicht in `visualizer/` — sonst kann `index.html` die Datei `../data/graph.json` nicht laden (Pythons `http.server` serviert nur Dateien innerhalb seines Start-Ordners). `--serve` macht das automatisch richtig.

**Hinweis:** `nmap`-Scans benötigen je nach Konfiguration erhöhte Rechte für bestimmte Scan-Typen (`sudo python3 run.py ...`, falls Berechtigungsfehler auftreten).

## Bekannte Grenzen (bewusst nicht gelöst, für ehrliche Einordnung)

- Die Risiko-Heuristik schaut nur auf Portnummern, nicht auf tatsächliche Schwachstellen oder CVEs — sie ersetzt keinen echten Vulnerability-Scanner (Nessus/OpenVAS).
- Keine Erkennung tatsächlicher Kommunikationsbeziehungen zwischen Geräten (bräuchte Traffic-Capture/NetFlow statt reinem Portscan).
- OS-Erkennung (`-O`) ist bewusst nicht aktiviert, um Scans schnell und unauffällig zu halten — könnte als Erweiterung ergänzt werden.

## Warum selbst gebaut statt ein fertiges Tool genutzt

Ziel war nicht, ein production-ready Asset-Management-Tool zu bauen, sondern zu verstehen, wie ein Tool wie BloodHound konzeptionell funktioniert — vom rohen Scan-Ergebnis über ein Graph-Datenmodell bis zur interaktiven Visualisierung — und das an einem Netzwerk zu üben, das man selbst kontrolliert.

---

## Phase 2: Live-Traffic- und Alert-Korrelation (Graph-Explorer)

Phase 1 beantwortet "was gibt es in meinem Netz". Phase 2 beantwortet die Frage, die im README von Phase 1 schon als bewusste Grenze benannt war: **"wer redet eigentlich tatsächlich mit wem, und ist das riskant?"** — dafür reicht ein einmaliger nmap-Snapshot nicht, das braucht echte, laufend aktualisierte Daten (Wazuh-Alerts, später OPNsense-Traffic).

### Architektur

```
homenet-mapper/
├── scanner/, visualizer/, run.py   # Phase 1 (unverändert) — nmap-Topologie-Snapshot
├── graphdb/
│   ├── docker-compose.yml          # startet Neo4j lokal
│   ├── schema.cypher               # Entitäts-/Beziehungsmodell (Constraints + Indizes)
│   └── connection.py                # Treiber-Wrapper + Schema-Setup
├── ingest/
│   ├── import_scan.py              # Bringt Phase-1-Scan-Ergebnisse als Host-Nodes in den Graphen
│   └── wazuh_ingest.py             # Holt Alerts aus dem Wazuh Indexer, verknüpft mit Host/ExternalIP
├── api/
│   └── main.py                      # FastAPI: liefert den Graphen als JSON fürs Frontend
└── visualizer_v2/
    └── index.html                   # Cytoscape.js-Graph-Explorer (dunkles Theme, Live-Daten)
```

### Warum Neo4j statt einfach die bestehende `graph.json` erweitern?

Phase 1 ist ein **einmaliger Snapshot** — eine flache JSON-Datei reicht, weil es keine Historie und keine Querverweise zwischen mehreren Quellen gibt. Phase 2 bringt mehrere, laufend aktualisierte Datenquellen zusammen, die sich gegenseitig referenzieren (derselbe Host taucht im nmap-Scan **und** in Wazuh-Alerts **und** später im OPNsense-Traffic auf). Fragen wie "zeig mir alles, was mit dieser IP in den letzten 24h zu tun hatte, über alle Quellen hinweg" sind klassische Graph-Abfragen:

- In einer flachen JSON-Datei müsste man das bei jedem Laden neu in JavaScript zusammensuchen — skaliert nicht, sobald die Datenmenge wächst.
- In einer normalen SQL-Tabelle braucht man dafür mehrere JOINs über Fremdschlüssel, und die Abfrage wird mit jeder neuen Beziehungsart komplizierter.
- Eine Graph-Datenbank speichert Beziehungen als erstklassige, indizierte Objekte — genau diese "wer hat womit zu tun"-Abfragen sind damit sowohl schnell als auch einfach zu schreiben (siehe `graphdb/schema.cypher`).

### Warum eine eigene FastAPI-Schicht statt das Frontend direkt mit Neo4j sprechen zu lassen

Zwei Gründe: Erstens sollen die Neo4j-Zugangsdaten nicht im Browser-JavaScript landen (jeder könnte sie im Quellcode lesen). Zweitens soll das Frontend nur "gib mir den Graphen der letzten X Stunden" sagen müssen — die eigentliche Query-Logik (welche Knoten, welche Kanten, wie gefiltert) gehört ins Backend, nicht in Client-JavaScript, das jeder im Browser verändern kann.

### Entitätsmodell

- **Host** — ein Gerät im eigenen Netz (IP, Hostname, MAC, Vendor, offene Ports aus Phase 1)
- **Alert** — ein einzelner Wazuh-Alert (Regel-ID, Beschreibung, Schweregrad, Zeitstempel)
- **ExternalIP** — eine IP außerhalb des eigenen Netzes, mit der ein Alert zu tun hatte (später angereichert mit Threat-Intel-Reputation)

Beziehungen: `(Host)-[:TRIGGERED]->(Alert)`, `(Alert)-[:INVOLVES]->(ExternalIP)`. Die Trennung zwischen "internen" und "externen" IPs passiert über die `HOME_NETWORKS`-Env-Var (eigene Subnetze konfigurieren) — alles außerhalb gilt als potenziell interessantes externes Ziel.

### Setup

```bash
pip install -r requirements.txt

# 1. Neo4j starten
cd graphdb && docker compose up -d && cd ..

# 2. Schema anlegen (Constraints + Indizes)
python3 graphdb/connection.py

# 3. Phase-1-Scan-Daten importieren (falls schon ein Scan gemacht wurde)
python3 ingest/import_scan.py

# 4. Wazuh-Alerts der letzten 24h importieren
export WAZUH_INDEXER_URL=https://<dein-wazuh-host>:9200
export WAZUH_USER=admin
export WAZUH_PASS=<dein-passwort>
export HOME_NETWORKS=192.168.10.0/24,192.168.20.0/24   # deine eigenen Subnetze
python3 ingest/wazuh_ingest.py 24

# 5. API starten
uvicorn api.main:app --reload --port 8000

# 6. Frontend öffnen (separates Terminal)
python3 -m http.server 8766
# Browser: http://localhost:8766/visualizer_v2/
```

### Bekannte Grenzen von Phase 2 (ehrliche Einordnung)

- **Kein echter Traffic noch** — aktuell nur Wazuh-Alerts, kein direkter Netzwerk-Traffic von OPNsense. Die `COMMUNICATED_WITH`-Beziehung im Schema ist vorbereitet, aber noch nicht befüllt (nächste Ausbaustufe).
- **Keine Threat-Intel-Anreicherung noch** — `ExternalIP`-Nodes haben ein `reputation`-Feld im API-Response vorgesehen, wird aber noch nicht befüllt (AbuseIPDB/OTX-Integration kommt in einer späteren Phase).
- **Ingestion ist ein manueller/periodischer Pull**, kein Live-Stream — für ein Homelab ausreichend, für Produktionsumgebungen würde man eher auf einen Push-Mechanismus (z.B. Wazuh-Integrations-Webhook) setzen.
- **Einfache Pagination bei der Wazuh-Abfrage** — `wazuh_ingest.py` holt nur die neuesten `size` Alerts statt per Scroll-API alle; für ein Homelab-Alertvolumen reicht das, bei sehr hohem Alert-Aufkommen müsste man auf Pagination umstellen.
