// schema.cypher -- Entitaets- und Beziehungsmodell fuer den Homenet-Graphen.
//
// Entitaeten (Node-Typen):
//   Host       -- ein Geraet im Netz, identifiziert ueber seine aktuelle IP
//                 (ip), optional hostname/mac/vendor aus dem nmap-Scan
//   Alert      -- ein einzelner Wazuh-Alert (id = Wazuh-Alert-ID, rule_id,
//                 rule_description, severity, timestamp)
//   ExternalIP -- eine IP ausserhalb des eigenen Netzes, mit der geredet
//                 wurde (spaeter mit Threat-Intel angereichert: reputation,
//                 country, asn)
//
// Beziehungen:
//   (:Host)-[:TRIGGERED]->(:Alert)        -- dieser Host hat den Alert ausgeloest
//   (:Alert)-[:INVOLVES]->(:ExternalIP)   -- der Alert betrifft diese externe IP
//   (:Host)-[:COMMUNICATED_WITH {port, protocol, first_seen, last_seen, count}]->(:ExternalIP)
//                                          -- (kommt in Phase 2b dazu: OPNsense-Traffic)
//
// Warum ueberhaupt Constraints/Indizes? Ohne sie wuerde Neo4j bei jedem
// Ingestion-Lauf pruefen, ob "gibt's diesen Host schon" per Komplett-Scan
// aller Host-Nodes -- bei wachsender Datenmenge immer langsamer. Ein
// eindeutiger Constraint erzwingt UND indiziert gleichzeitig.

CREATE CONSTRAINT host_ip IF NOT EXISTS
FOR (h:Host) REQUIRE h.ip IS UNIQUE;

CREATE CONSTRAINT alert_id IF NOT EXISTS
FOR (a:Alert) REQUIRE a.id IS UNIQUE;

CREATE CONSTRAINT external_ip IF NOT EXISTS
FOR (e:ExternalIP) REQUIRE e.ip IS UNIQUE;

// Haeufige Abfrage: "alle Alerts der letzten X Stunden" -- Index auf
// Zeitstempel macht das schnell statt jeden Alert-Node einzeln anzusehen.
CREATE INDEX alert_timestamp IF NOT EXISTS
FOR (a:Alert) ON (a.timestamp);
